import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Home as HomeIcon, 
  Search as SearchIcon, 
  Users, 
  Library as LibraryIcon, 
  Music, 
  Play, 
  SkipBack, 
  SkipForward, 
  Heart,
  Settings,
  CreditCard,
  Mic2,
  X,
  LogOut,
  Zap,
  Menu,
  Bell,
  Gift,
  Copy,
  Info,
  ExternalLink
} from "lucide-react";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp, onSnapshot, collection, query, orderBy, limit, updateDoc, increment, where } from "firebase/firestore";

import { auth, loginWithGoogle, logout, db, handleFirestoreError, OperationType } from "./lib/firebase";
import Home from "./screens/Home";
import Search from "./screens/Search";
import Community from "./screens/Community";
import Library from "./screens/Library";
import Profile from "./screens/Profile";
import Studio from "./screens/Studio";
import Pricing from "./screens/Pricing";
import Legal from "./screens/Legal";
import { Button, GlassCard } from "./components/UI";

type Screen = 'home' | 'search' | 'community' | 'library' | 'studio' | 'pricing' | 'legal' | 'profile' | 'notifications';

interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  plan: 'free' | 'standard' | 'premium';
  credits: number;
  aiVersion: string;
  referralCode?: string;
  referredCount?: number;
  bio?: string;
  nationality?: string;
  residence?: string;
  zodiacSign?: string;
  avatarVideoUrl?: string;
}

export default function App() {
  const [activeScreen, setActiveScreen] = useState<Screen>('home');
  const [activeSubView, setActiveSubView] = useState<string | null>(null);
  const [showAuth, setShowAuth] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState<{title: string, author: string, audioUrl: string, cover: string} | null>(null);

  useEffect(() => {
    const handlePlayTrack = (e: any) => {
      setCurrentTrack(e.detail);
      setIsPlaying(true);
    };

    window.addEventListener('play-track', handlePlayTrack);
    return () => window.removeEventListener('play-track', handlePlayTrack);
  }, []);

  useEffect(() => {
    let profileUnsub: (() => void) | undefined;
    let notifUnsub: (() => void) | undefined;

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      if (user) {
        // Real-time profile sync
        const userRef = doc(db, 'users', user.uid);
        profileUnsub = onSnapshot(userRef, (snap) => {
          if (snap.exists()) {
            setProfile(snap.data() as UserProfile);
          } else {
            // ... (keep rest of init logic)
            const urlParams = new URLSearchParams(window.location.search);
            const refCode = urlParams.get('ref');

            const newProfile: UserProfile = {
              uid: user.uid,
              email: user.email,
              displayName: user.displayName,
              plan: 'free',
              credits: refCode ? 70 : 50, // Extra credits for referred users
              aiVersion: "3.5",
              referralCode: `C8L-${user.uid.slice(0, 5).toUpperCase()}`,
              referredCount: 0
            };
            
            const initProfile = async () => {
              try {
                await setDoc(userRef, {
                  ...newProfile,
                  followersCount: 0,
                  createdAt: serverTimestamp(),
                  updatedAt: serverTimestamp()
                });
              } catch (e) {
                handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}`);
              }
            };
            initProfile();

            // If referred, we should ideally notify/update the referrer too
            // Note: In a real app this would be a server-side function to prevent self-referral abuse
            if (refCode) {
              console.log("Joined via referral:", refCode);
              // Clean up URL
              window.history.replaceState({}, document.title, window.location.pathname);
            }

            setProfile(newProfile);
          }
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
        });

        // Notifications listener
        const notifPath = "notifications";
        const notifQuery = query(
          collection(db, notifPath), 
          where("userId", "==", user.uid),
          orderBy("createdAt", "desc"), 
          limit(5)
        );
        notifUnsub = onSnapshot(notifQuery, (snap) => {
          setNotifications(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        }, (error) => {
          handleFirestoreError(error, OperationType.LIST, notifPath);
        });
      } else {
        setProfile(null);
        if (profileUnsub) profileUnsub();
        if (notifUnsub) notifUnsub();
      }
    });
    return () => {
      unsubscribe();
      if (profileUnsub) profileUnsub();
      if (notifUnsub) notifUnsub();
    };
  }, []);

  const handleCopyReferral = () => {
    if (!profile) return;
    const url = `${window.location.origin}?ref=${profile.referralCode}`;
    navigator.clipboard.writeText(url);
    alert("¡Enlace de referido copiado! Compártelo para ganar 20 créditos por cada amigo.");
  };

  const handleWatchAd = async () => {
    if (!user) return;
    alert("Iniciando anuncio... (Simulación de 5 segundos)");
    setTimeout(async () => {
      try {
        await updateDoc(doc(db, "users", user.uid), {
          credits: increment(10),
          updatedAt: serverTimestamp()
        });
        alert("¡Felicidades! Has ganado 10 créditos por ver el anuncio.");
      } catch (e) {
        handleFirestoreError(e, OperationType.UPDATE, `users/${user.uid}`);
      }
    }, 5000);
  };

  const handleLogin = async () => {
    try {
      await loginWithGoogle();
      setShowAuth(false);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  const handleLogout = async () => {
    await logout();
    setActiveScreen('home');
  };

  const handleNavigate = (screen: Screen, subView: string | null = null) => {
    setActiveScreen(screen);
    setActiveSubView(subView);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderScreen = () => {
    switch (activeScreen) {
      case 'home': return <Home onNavigate={handleNavigate} />;
      case 'search': return <Search />;
      case 'community': return <Community initialView={activeSubView} onBack={() => setActiveSubView(null)} onNavigate={handleNavigate} />;
      case 'library': return <Library />;
      case 'profile': return <Profile />;
      case 'studio': return <Studio />;
      case 'pricing': return <Pricing onNavigate={handleNavigate} />;
      case 'legal': return <Legal />;
      case 'notifications': return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="flex items-center gap-4">
             <div className="p-4 rounded-3xl bg-primary/10 text-primary">
                <Bell size={32} />
             </div>
             <div>
                <h2 className="text-4xl font-display font-black tracking-tighter text-white">Notificaciones</h2>
                <p className="text-white/40 text-xs font-black uppercase tracking-widest">Tus novedades en tiempo real</p>
             </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {notifications.length > 0 ? notifications.map((n: any) => (
              <GlassCard key={n.id} className="p-6 space-y-4 hover:border-primary/30 transition-all group">
                <div className="flex justify-between items-start">
                  <span className={`text-[9px] font-black uppercase px-2 py-1 rounded-lg ${
                    n.type === 'update' ? 'bg-primary/20 text-primary' : 
                    n.type === 'reward' ? 'bg-secondary/20 text-secondary' : 'bg-white/10 text-white/60'
                  }`}>
                    {n.type}
                  </span>
                  <span className="text-[9px] font-bold text-white/20 uppercase">
                    {n.createdAt?.toDate ? new Date(n.createdAt.toDate()).toLocaleDateString() : 'Hoy'}
                  </span>
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-white group-hover:text-primary transition-colors">{n.title}</h4>
                  <p className="text-xs text-white/40 leading-relaxed">{n.message}</p>
                </div>
              </GlassCard>
            )) : (
              <div className="md:col-span-3 py-20 flex flex-col items-center justify-center opacity-20 space-y-4">
                <Bell size={64} strokeWidth={1} />
                <p className="text-sm font-bold uppercase tracking-widest tracking-[0.3em]">Bandeja vacía</p>
              </div>
            )}
          </div>
        </div>
      );
      default: return <Home onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#000000] text-white relative flex font-sans">
      {/* Sidebar Navigation - Ultra Thin Unified Sidebar */}
      <aside className="fixed left-0 top-0 bottom-0 w-16 glass border-r border-white/10 z-[70] flex flex-col items-center py-6 overflow-y-auto hide-scrollbar lg:w-20 transition-all">
        <div className="flex flex-col items-center w-full gap-8">
          {/* logo - Mini version */}
          <div 
            className="cursor-pointer group flex flex-col items-center"
            onClick={() => handleNavigate('home')}
          >
            <div className="w-10 h-10 lg:w-12 lg:h-12 flex items-center justify-center p-2">
              <img 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuD4siq0egagRFePO3b4ePuSd8Ow58SvDtgQ13mxhJEvvRXyxj0cO_88Uzcswan_g2ZnFyYYl6d5NI5OsaOSw9UZLSXDUbjmiegbHpBhmI2IWIyhG_bDBPTYGuQY3Hir9JCE6_m1VCUotTcefFU7eRLClLTJc9LgI77mH5XQkRzmDeUfQjwNvGHIWNc9cmFmzjHY36Yjit46VE2PJb4xi7oKkDnPw2cm7NCws5CCFuG66gQVkpNMjfFwAJhTN2PsiDydnB1JTXwCSWk" 
                alt="Logo" 
                className="w-full h-full object-contain invert opacity-90 group-hover:scale-110 transition-all drop-shadow-[0_0_10px_rgba(168,85,247,0.5)]"
              />
            </div>
          </div>

          {/* User Profile - Compact Mini */}
          {user && profile ? (
            <div 
              onClick={() => handleNavigate('profile')}
              className="flex flex-col items-center gap-2 cursor-pointer group"
            >
              <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-full overflow-hidden border-2 border-primary/20 group-hover:border-primary transition-all relative p-0.5">
                 <img src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`} alt="User" className="w-full h-full object-cover rounded-full" />
                 <div className="absolute inset-0 bg-primary/20 animate-pulse opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
          ) : (
            <button 
              onClick={() => setShowAuth(true)}
              className="w-10 h-10 rounded-xl bg-primary-container text-white flex items-center justify-center hover:scale-110 transition-all glow-purple"
            >
              <Zap size={16} fill="currentColor" />
            </button>
          )}

          {/* Main Navigation - Vertical Icons */}
          <nav className="flex flex-col items-center gap-2 w-full px-2">
            {[
              { id: 'home', icon: HomeIcon, label: 'Inicio' },
              { id: 'search', icon: SearchIcon, label: 'Buscar' },
              { id: 'studio', icon: Mic2, label: 'Studio' },
              { id: 'community', icon: Users, label: 'Club' },
              { id: 'notifications', icon: Bell, label: 'Avisos', badge: notifications.length > 0 }
            ].map((item, index) => (
              <button
                key={`${item.id}-${index}`}
                onClick={() => handleNavigate(item.id as Screen)}
                className={`w-full aspect-square flex flex-col items-center justify-center rounded-2xl transition-all relative group
                  ${activeScreen === item.id ? 'bg-primary/10 text-primary border border-primary/20 glow-purple' : 'text-white/20 hover:text-white hover:bg-white/5'}
                `}
                title={item.label}
              >
                <item.icon size={20} className={activeScreen === item.id ? "drop-shadow-[0_0_8px_rgba(168,85,247,0.5)]" : ""} />
                <span className="text-[7px] mt-1 font-black uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">{item.label}</span>
                {item.badge && (
                  <span className="absolute top-3 right-3 w-2 h-2 bg-red-500 rounded-full border-2 border-black" />
                )}
                {activeScreen === item.id && (
                  <motion.div 
                    layoutId="sidebar-active"
                    className="absolute left-[-2px] w-1 h-6 bg-primary rounded-full glow-purple shadow-primary"
                  />
                )}
              </button>
            ))}
          </nav>
        </div>

        {/* Bottom Section - Mini */}
        <div className="mt-auto flex flex-col items-center gap-4 pb-4">
           <button 
             onClick={() => handleNavigate('pricing')}
             className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-white/20 hover:text-primary transition-colors"
           >
             <CreditCard size={14} />
           </button>
           
           <button 
             onClick={() => handleNavigate('legal')}
             className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-white/20 hover:text-white transition-colors"
           >
             <Info size={14} />
           </button>

           {user && (
             <button 
               onClick={handleLogout}
               className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-white/20 hover:text-red-400 transition-colors"
             >
               <LogOut size={14} />
             </button>
           )}
        </div>
      </aside>

      {/* Content Container */}
      <div className="flex-1 ml-16 lg:ml-20 flex flex-col min-h-screen max-w-full overflow-x-hidden">
        {/* Top Header Placeholder (Minimal) */}
        {user && profile && activeScreen !== 'profile' && (
           <div className="fixed top-0 left-16 lg:left-20 right-0 h-16 pointer-events-none z-40 px-4 lg:px-8 flex items-center justify-end gap-4">
              {/* Notification Bell */}
              <div className="pointer-events-auto relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className={`p-2 rounded-2xl border transition-all ${showNotifications ? 'bg-primary/20 border-primary text-primary' : 'bg-black/40 backdrop-blur-md border-white/5 text-white/40 hover:text-white'}`}
                >
                  <Bell size={20} />
                  {notifications.length > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-black" />
                  )}
                </button>

                <AnimatePresence>
                  {showNotifications && (
                    <>
                      <div 
                        className="fixed inset-0 z-[-1]" 
                        onClick={() => setShowNotifications(false)} 
                      />
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute right-0 mt-4 w-80 bg-black/90 backdrop-blur-2xl border border-white/10 rounded-3xl shadow-2xl overflow-hidden z-50 origin-top-right"
                      >
                        <div className="p-5 border-b border-white/5 flex items-center justify-between">
                          <h4 className="text-xs font-black uppercase tracking-widest text-white">Novedades</h4>
                          <button 
                            onClick={() => {
                              setShowNotifications(false);
                              handleNavigate('notifications');
                            }}
                            className="text-[10px] font-bold text-primary hover:underline"
                          >
                            Ver todo
                          </button>
                        </div>
                        <div className="max-h-80 overflow-y-auto">
                          {notifications.length > 0 ? (
                            notifications.map((n) => (
                              <div 
                                key={n.id} 
                                className="p-4 border-b border-white/5 hover:bg-white/5 transition-colors cursor-pointer group"
                                onClick={() => {
                                  setShowNotifications(false);
                                  handleNavigate('notifications');
                                }}
                              >
                                <div className="flex gap-3">
                                  <div className={`mt-1 shrink-0 w-2 h-2 rounded-full ${
                                    n.type === 'update' ? 'bg-primary' : 
                                    n.type === 'reward' ? 'bg-secondary' : 'bg-white/40'
                                  }`} />
                                  <div className="space-y-1">
                                    <p className="text-[11px] font-bold text-white group-hover:text-primary transition-colors">{n.title}</p>
                                    <p className="text-[10px] text-white/40 line-clamp-2 leading-relaxed">{n.message}</p>
                                  </div>
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="p-10 text-center space-y-2 opacity-20">
                              <Bell className="mx-auto" size={24} />
                              <p className="text-[10px] font-black uppercase tracking-widest">Sin novedades</p>
                            </div>
                          )}
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>

              <div className="pointer-events-auto flex items-center gap-2 bg-black/40 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/5 shadow-xl">
                 <Zap size={14} className="text-secondary animate-pulse" />
                 <span className="text-xs font-black">{profile.credits} cr.</span>
                 <button onClick={handleWatchAd} className="ml-2 text-primary hover:scale-110 transition-transform">
                    <Gift size={16} />
                 </button>
              </div>
           </div>
        )}


        <main className="pt-20 pb-40 px-2 lg:px-12 max-w-full min-h-screen">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeScreen}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.3 }}
            >
              {renderScreen()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Now Playing Bar */}
      <div className="fixed bottom-6 lg:bottom-8 left-20 lg:left-24 right-4 lg:right-8 z-40">
        {currentTrack && (
          <audio 
            autoPlay={isPlaying}
            src={currentTrack.audioUrl} 
            key={currentTrack.audioUrl}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            ref={(el) => {
              if (el) {
                if (isPlaying) el.play().catch(() => {});
                else el.pause();
              }
            }}
          />
        )}
        <GlassCard className="p-2 lg:p-3 pr-4 lg:pr-6 flex items-center justify-between glow-purple !bg-black/90 backdrop-blur-3xl border-white/10 shadow-2xl">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full overflow-hidden shrink-0 relative group">
              <img src={currentTrack?.cover || "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=100"} className="w-full h-full object-cover" alt="Album" />
              <div className={`absolute inset-0 bg-primary/20 ${isPlaying ? 'animate-pulse' : ''}`}></div>
            </div>
            <div className="min-w-0">
              <h4 className="text-sm font-bold text-white truncate">{currentTrack?.title || "C.8.L. Music AI"}</h4>
              <p className="text-[10px] text-white/40 uppercase tracking-widest font-bold">{currentTrack?.author || "Varios Artistas"} • C8L Universe</p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden sm:flex items-center gap-6 text-white/40">
              <button className="hover:text-white transition-colors"><Heart size={18} /></button>
              <button className="hover:text-white transition-colors"><SkipBack size={20} /></button>
            </div>
            
            <button 
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-all"
            >
              <Play size={24} fill="currentColor" stroke="none" className={isPlaying ? 'hidden' : 'block'} />
              <div className={`flex gap-1 ${isPlaying ? 'block' : 'hidden'}`}>
                <div className="w-1 h-4 bg-black animate-pulse"></div>
                <div className="w-1 h-4 bg-black animate-pulse delay-75"></div>
              </div>
            </button>

            <button className="text-white/40 hover:text-white transition-colors hidden sm:block">
              <SkipForward size={20} />
            </button>
          </div>

          {/* Progress Bar */}
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[90%] h-[2px] bg-white/5 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: "30%" }}
              animate={isPlaying ? { width: "100%" } : {}}
              transition={{ duration: 180, ease: "linear" }}
              className="h-full bg-primary glow-purple"
            />
          </div>
        </GlassCard>
      </div>

      {/* Auth Modal */}
      <AnimatePresence>
        {showAuth && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <GlassCard className="max-w-md w-full p-10 space-y-8 relative">
                <button 
                  onClick={() => setShowAuth(false)}
                  className="absolute top-6 right-6 text-white/40 hover:text-white"
                >
                  <X />
                </button>
                
                <div className="text-center space-y-4">
                  <div className="w-20 h-20 rounded-2xl overflow-hidden mx-auto shadow-2xl group relative">
                    <img 
                      src="https://images.unsplash.com/photo-1514525253361-b83f83df915e?q=80&w=200" 
                      alt="C.8.L. Music AI" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="space-y-1">
                    <h2 className="text-3xl font-display font-black tracking-tighter uppercase">C.8.L. Music AI</h2>
                    <p className="text-[10px] font-black uppercase text-primary tracking-[0.3em]">C8L Universe</p>
                  </div>
                  <p className="text-white/40 text-sm">Registro rápido. Empieza a crear en segundos.</p>
                </div>

                <div className="space-y-4">
                  <Button fullWidth onClick={handleLogin}>Continuar con Google</Button>
                </div>

                <div className="text-center">
                  <p className="text-xs text-white/20">Al unirte aceptas nuestros términos legales y de privacidad.</p>
                </div>
              </GlassCard>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

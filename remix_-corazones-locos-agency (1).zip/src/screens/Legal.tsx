import { ShieldCheck, Gavel, FileText, Globe, Scale, Star } from "lucide-react";
import { GlassCard } from "../components/UI";

export default function Legal() {
  return (
    <div className="max-w-4xl mx-auto space-y-16 animate-in fade-in slide-in-from-bottom-4 duration-700 py-12">
      <header className="space-y-4">
        <span className="text-primary font-bold uppercase tracking-[0.3em] text-[10px]">Dosier Corporativo</span>
        <h2 className="text-5xl md:text-6xl font-display font-black tracking-tighter">Transparencia <br/><span className="gradient-text">Legal y Empresarial.</span></h2>
        <p className="text-white/60 text-lg leading-relaxed">
          C.8.L. Music AI es un ecosistema tecnológico diseñado para la nueva era de la industria musical, operando bajo estándares de máxima seguridad y cumplimiento normativo internacional.
        </p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-12 gap-6">
        <GlassCard className="md:col-span-8 p-10 space-y-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <Scale size={160} />
          </div>
          <h3 className="text-3xl font-display font-black">Estructura Corporativa</h3>
          <div className="space-y-8">
            <div className="flex gap-6">
              <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center shrink-0">
                <Globe className="text-secondary" size={28} />
              </div>
              <div>
                <h4 className="text-xl font-bold mb-1">C.8.L. Agency S.L.</h4>
                <p className="text-white/40 text-sm leading-relaxed">
                  Entidad legal responsable de la gestión de licencias, facturación y gobernanza global de la plataforma, con sede en Madrid, España.
                </p>
              </div>
            </div>
            <div className="flex gap-6">
              <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center shrink-0">
                <ShieldCheck className="text-primary" size={28} />
              </div>
              <div>
                <h4 className="text-xl font-bold mb-1">Protección de Datos & Privacidad</h4>
                <p className="text-white/40 text-sm leading-relaxed">
                  Cumplimiento estricto del RGPD. Los datos de nuestros artistas son encriptados mediante protocolos AES-256 de grado militar.
                </p>
              </div>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="md:col-span-4 p-10 flex flex-col items-center justify-center text-center gap-6">
           <div className="w-24 h-24 rounded-3xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=200" 
                alt="C8L Logo" 
                className="w-full h-full object-cover"
              />
           </div>
           <div>
              <p className="text-xl font-display font-black tracking-tighter text-white">C.8.L. Music AI</p>
              <p className="text-xs font-bold uppercase tracking-widest text-primary mb-2">C.8.L. Universe</p>
              <p className="text-white/40 text-[10px]">Identidad • Pulsación creativa • Transparencia.</p>
           </div>
        </GlassCard>
      </section>

      <section className="p-10 rounded-3xl bg-gradient-to-r from-primary/10 to-tertiary/10 border border-white/5 space-y-8">
        <div className="flex flex-col md:flex-row gap-8 items-start md:items-center">
          <Star size={48} className="text-tertiary" />
          <div className="space-y-2">
            <h3 className="text-3xl font-display font-black">Derechos Globales Premium</h3>
            <p className="text-white/70 max-w-2xl">
              Los suscriptores de Studio adquieren automáticamente licencias de promoción global y derechos prioritarios sobre sus creaciones.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
           {[
             { title: "Royalties Directos", desc: "Liquidación transparente en tiempo real." },
             { title: "Soporte Legal", desc: "Gestión técnica de propiedad intelectual." },
             { title: "Distribución", desc: "Acceso a +120 territorios internacionales." }
           ].map((item, i) => (
             <div key={i} className="glass-light p-5 rounded-2xl space-y-2">
               <p className="font-bold text-sm text-white">{item.title}</p>
               <p className="text-white/40 text-[11px] leading-snug">{item.desc}</p>
             </div>
           ))}
        </div>
      </section>

      <footer className="text-center pt-8 space-y-6">
        <div className="flex justify-center gap-8 text-white/40">
           <Gavel className="hover:text-primary transition-colors cursor-pointer" size={24} />
           <FileText className="hover:text-primary transition-colors cursor-pointer" size={24} />
           <ShieldCheck className="hover:text-primary transition-colors cursor-pointer" size={24} />
        </div>
        <p className="text-[10px] text-white/20 uppercase tracking-[0.2em]">C.8.L. Agency S.L. • Todos los derechos reservados • 2026</p>
      </footer>
    </div>
  );
}

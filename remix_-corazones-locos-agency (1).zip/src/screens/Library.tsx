import { useState, useEffect } from "react";
import { Play, Clock, Heart, MoreVertical, LayoutGrid, Loader2, Share2 } from "lucide-react";
import { collection, query, where, orderBy, onSnapshot } from "firebase/firestore";

import { GlassCard } from "../components/UI";
import { auth, db, handleFirestoreError, OperationType } from "../lib/firebase";

interface SongRecord {
  id: string;
  title: string;
  artist: string;
  genre: string;
  tempo: string;
  mood: string;
  lyrics: string[];
  audioUrl?: string;
  createdAt: any;
}

export default function Library() {
  const [songs, setSongs] = useState<SongRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!auth.currentUser) {
      setSongs([]);
      setIsLoading(false);
      return;
    }

    const path = 'songs';
    const q = query(
      collection(db, path),
      where("ownerId", "==", auth.currentUser.uid),
      orderBy("createdAt", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as SongRecord[];
      setSongs(docs);
      setIsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handlePlay = (song: SongRecord) => {
    const playEvent = new CustomEvent('play-track', { 
      detail: { 
        title: song.title, 
        author: song.artist,
        audioUrl: song.audioUrl,
        cover: `https://images.unsplash.com/photo-1614149162883-504ce4d13909?q=80&w=200&sig=${song.id}`
      } 
    });
    window.dispatchEvent(playEvent);
  };

  const handleShare = (songId: string) => {
    const url = window.location.origin + `?songId=${songId}`;
    navigator.clipboard.writeText(url);
    alert("¡Enlace de la canción copiado!");
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="space-y-6">
        <h2 className="text-5xl font-display font-black">Biblioteca</h2>
        <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
          {["Canciones", "Álbumes", "Artistas", "Playlists", "Recientes"].map((text, i) => (
            <button 
              key={i}
              className={`px-6 py-2 rounded-full border border-white/5 whitespace-nowrap font-bold text-xs uppercase tracking-widest transition-all
                ${i === 0 ? 'bg-primary text-white glow-purple border-primary' : 'text-white/40 hover:bg-white/5 hover:text-white'}
              `}
            >
              {text}
            </button>
          ))}
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <GlassCard className="md:col-span-2 relative p-8 group min-h-[200px]">
          <div className="absolute inset-0 opacity-30">
            <img src="https://images.unsplash.com/photo-1516280440614-37939bbacd81?q=80&w=800" className="w-full h-full object-cover" alt="Library Background" />
          </div>
          <div className="relative z-10 h-full flex flex-col justify-end">
             <span className="text-secondary font-bold uppercase tracking-widest text-[10px] mb-2">Más escuchadas</span>
             <h3 className="text-4xl font-display font-black text-white mb-4">Tu Verano 2024</h3>
             <div className="flex items-center gap-4">
                <button className="w-12 h-12 rounded-full bg-secondary text-white flex items-center justify-center glow-green transform hover:scale-110 transition-transform">
                  <Play fill="white" size={24} />
                </button>
                <p className="text-white/60 font-bold">48 canciones • 2h 45m</p>
             </div>
          </div>
        </GlassCard>

        <GlassCard className="p-8 flex flex-col justify-between border-primary/20">
          <div>
             <LayoutGrid className="text-primary mb-4" size={32} />
             <h3 className="text-xl font-display font-black">Mix Diario</h3>
             <p className="text-white/40 text-sm mt-1">Basado en tus artistas favoritos recientes.</p>
          </div>
          <div className="flex -space-x-3 mt-4">
             {[1,2,3,4].map(idx => (
               <div key={idx} className="w-10 h-10 rounded-full border-2 border-black bg-surface-bright overflow-hidden">
                 <img src={`https://i.pravatar.cc/100?img=${idx + 10}`} className="w-full h-full object-cover" alt="Artist" />
               </div>
             ))}
             <div className="w-10 h-10 rounded-full border-2 border-black bg-primary text-white flex items-center justify-center text-[10px] font-bold">+5</div>
          </div>
        </GlassCard>
      </div>

      <section className="space-y-6">
        <div className="flex justify-between items-center">
           <h3 className="text-2xl font-display font-black">Canciones guardadas</h3>
           <button className="text-primary text-[10px] font-bold uppercase tracking-widest hover:underline">Ver todas</button>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="animate-spin text-primary" size={32} />
          </div>
        ) : songs.length === 0 ? (
          <div className="text-center py-12 p-8 glass rounded-2xl border-dashed border-white/10 opacity-60">
            <p className="text-white/40">No tienes canciones guardadas todavía.</p>
            <p className="text-xs text-white/20 mt-2">Visita el Studio para crear tu primera pista.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {songs.map((song, i) => (
              <div key={song.id} className="flex items-center gap-4 p-3 rounded-2xl hover:bg-white/5 transition-all group">
                <div 
                  className="relative w-14 h-14 rounded-xl overflow-hidden shrink-0 cursor-pointer"
                  onClick={() => handlePlay(song)}
                >
                  <img src={`https://images.unsplash.com/photo-1614149162883-504ce4d13909?q=80&w=200&sig=${song.id}`} className="w-full h-full object-cover" alt={song.title} />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play fill="white" size={20} />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h6 className="font-bold text-white group-hover:text-primary transition-colors truncate">{song.title}</h6>
                  <p className="text-white/40 text-xs truncate">{song.artist} • {song.genre}</p>
                </div>
                <div className="hidden md:flex items-center gap-8 text-white/40 text-xs uppercase tracking-widest font-bold">
                  <span>{song.tempo} BPM</span>
                  <button onClick={() => handleShare(song.id)} className="hover:text-primary transition-colors">
                    <Share2 size={18} />
                  </button>
                  <Heart size={18} />
                </div>
                <button className="text-white/20 hover:text-white transition-colors">
                  <MoreVertical size={20} />
                </button>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

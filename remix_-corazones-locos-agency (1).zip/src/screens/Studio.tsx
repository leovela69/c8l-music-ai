import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, Music, Video, Send, Loader2, Save, Check, X,
  Mic2, Ban, Sliders, ChevronDown, UserCheck, Upload, Database, Download, Lock, Zap, Share2, Play, Shield, Wand2,
  RefreshCw, Forward, History, Star, ThumbsUp, ThumbsDown, MoreVertical, FileAudio
} from "lucide-react";
import { doc, onSnapshot, collection, addDoc, serverTimestamp } from "firebase/firestore";

import { GlassCard, Button } from "../components/UI";
import { auth, db, handleFirestoreError, OperationType } from "../lib/firebase";
import { aiService } from "../services/aiService";
import ProStudio from "./ProStudio";

export default function Studio() {
  const [hasStarted, setHasStarted] = useState(false);
  
  // Inputs
  const [lyricsPrompt, setLyricsPrompt] = useState("");
  const [positiveStyle, setPositiveStyle] = useState("");
  const [negativeStyle, setNegativeStyle] = useState("");
  const [title, setTitle] = useState("");
  
  // AI Loading States
  const [isRefiningLyrics, setIsRefiningLyrics] = useState(false);
  const [isRefiningPositive, setIsRefiningPositive] = useState(false);
  const [isRefiningNegative, setIsRefiningNegative] = useState(false);
  
  // States
  const [userProfile, setUserProfile] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedTracks, setGeneratedTracks] = useState<{id: string, title: string, style: string, lyrics: string, audioUrl?: string}[]>([]);
  const [coversToday, setCoversToday] = useState(0); // Mock daily counter
  const [savingTrackId, setSavingTrackId] = useState<string | null>(null);
  const [savedTracks, setSavedTracks] = useState<string[]>([]);
  const [isProcessingTool, setIsProcessingTool] = useState<string | null>(null);
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [trackFeedback, setTrackFeedback] = useState<{[key: string]: 'up' | 'down' | null}>({});

  useEffect(() => {
    if (!auth.currentUser) return;
    const userRef = doc(db, 'users', auth.currentUser.uid);
    const unsubscribe = onSnapshot(userRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setUserProfile(data);
        // Initial mock load
        if (data.plan === 'free') {
          setCoversToday(2); 
        }
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${auth.currentUser?.uid}`);
    });
    return () => unsubscribe();
  }, []);

  const [showVideoclip, setShowVideoclip] = useState<any | null>(null);
  const [showProStudio, setShowProStudio] = useState<any | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isVideoGenerating, setIsVideoGenerating] = useState(false);
  const [videoProgress, setVideoProgress] = useState(0);
  const [videoFinished, setVideoFinished] = useState(false);

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const startVideoGeneration = () => {
    if (!uploadedImage) return;
    setIsVideoGenerating(true);
    setVideoProgress(0);
    const interval = setInterval(() => {
      setVideoProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setVideoFinished(true);
          setIsVideoGenerating(false);
          return 100;
        }
        return prev + 2;
      });
    }, 200);
  };

  const downloadVideo = () => {
    // Mock download for the generated video clip
    const link = document.createElement("a");
    link.href = uploadedImage || ""; // Using image as placeholder for download
    link.download = `C8L_MusicVideo_${showVideoclip?.title || "Track"}.mp4`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    alert("¡Descargando videoclip generado por IA!");
  };

  const handleGenerate = async () => {
    if (!positiveStyle.trim() && !lyricsPrompt.trim()) return;
    if (!userProfile) return;

    const limit = userProfile.plan === 'free' ? 5 : 50;
    if (coversToday >= limit) {
      alert(`Has alcanzado tu límite diario de ${limit} covers. Se renovará en 24 horas.`);
      return;
    }

    setIsGenerating(true);
    setGeneratedTracks([]);

    // Simulate AI thinking and generating 2 variations
    setTimeout(() => {
      setGeneratedTracks([
        { 
          id: `v1-${Date.now()}`, 
          title: title || "Track Variation A", 
          style: positiveStyle, 
          lyrics: lyricsPrompt,
          audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" 
        },
        { 
          id: `v2-${Date.now()}`, 
          title: title || "Track Variation B", 
          style: positiveStyle, 
          lyrics: lyricsPrompt,
          audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3" 
        }
      ]);
      setCoversToday(prev => prev + 1);
      setIsGenerating(false);
    }, 4000);
  };

  const handleAIRefineLyrics = async () => {
    setIsRefiningLyrics(true);
    try {
      const refined = await aiService.refineLyrics(lyricsPrompt);
      setLyricsPrompt(refined);
    } catch (error) {
      console.error(error);
    } finally {
      setIsRefiningLyrics(false);
    }
  };

  const handleAIRefinePositive = async () => {
    if (!positiveStyle.trim()) return;
    setIsRefiningPositive(true);
    try {
      const refined = await aiService.refinePrompt(positiveStyle, false);
      setPositiveStyle(refined);
    } catch (error) {
      console.error(error);
    } finally {
      setIsRefiningPositive(false);
    }
  };

  const handleAIRefineNegative = async () => {
    if (!negativeStyle.trim()) return;
    setIsRefiningNegative(true);
    try {
      const refined = await aiService.refinePrompt(negativeStyle, true);
      setNegativeStyle(refined);
    } catch (error) {
      console.error(error);
    } finally {
      setIsRefiningNegative(false);
    }
  };

  const handleReuse = (track: any) => {
    setLyricsPrompt(track.lyrics || lyricsPrompt);
    setPositiveStyle(track.style);
    setTitle(`Remix - ${track.title}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSave = async (track: any) => {
    if (!auth.currentUser) return;
    setSavingTrackId(track.id);
    try {
      await addDoc(collection(db, 'songs'), {
        ownerId: auth.currentUser.uid,
        title: track.title,
        artist: userProfile?.displayName || "Artista Desconocido",
        genre: track.style,
        lyrics: [track.lyrics],
        audioUrl: track.audioUrl,
        createdAt: serverTimestamp(),
        tempo: "128", // Mock
        mood: "AI Generated" // Mock
      });
      setSavedTracks(prev => [...prev, track.id]);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'songs');
    } finally {
      setSavingTrackId(null);
    }
  };

  const handleExtension = async (track: any) => {
    setIsProcessingTool(track.id + '-ext');
    try {
      const extendedLyrics = await aiService.extendLyrics(track.lyrics);
      setLyricsPrompt(extendedLyrics);
      setPositiveStyle(track.style);
      setTitle(`Ext - ${track.title}`);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } finally {
      setIsProcessingTool(null);
    }
  };

  const handleRemix = async (track: any) => {
    setIsProcessingTool(track.id + '-remix');
    try {
      const remixStyle = await aiService.createRemixPrompt(track.style);
      setLyricsPrompt(track.lyrics);
      setPositiveStyle(remixStyle);
      setTitle(`Remix - ${track.title}`);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } finally {
      setIsProcessingTool(null);
    }
  };

  const handleShare = async (track: any) => {
    const shareData = {
      title: `${track.title} - C8L Music AI`,
      text: `¡Mira esta canción que acabo de crear con IA! Estilo: ${track.style}`,
      url: window.location.href
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(window.location.href);
        alert("¡Enlace copiado al portapapeles!");
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDownload = (track: any, format: 'mp3' | 'wav' = 'mp3') => {
    if (!track.audioUrl) return;
    const link = document.createElement("a");
    link.href = track.audioUrl;
    link.download = `${track.title}.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleFeedback = (trackId: string, type: 'up' | 'down') => {
    setTrackFeedback(prev => ({
      ...prev,
      [trackId]: prev[trackId] === type ? null : type
    }));
  };

  const handlePlay = (track: any) => {
    // Custom event to handle playback in App.tsx
    const playEvent = new CustomEvent('play-track', { 
      detail: { 
        title: track.title, 
        author: userProfile?.displayName || "Tú",
        audioUrl: track.audioUrl,
        cover: "https://images.unsplash.com/photo-1514525253361-b83f83df915e?q=80&w=300"
      } 
    });
    window.dispatchEvent(playEvent);
  };

  const modelName = userProfile?.plan === 'free' ? "AI Model 3.5 (Económica)" : (userProfile?.plan === 'premium' ? "AI Master 5.5 (Supreme)" : "AI Pro 4.0 (Balanced)");

  if (!hasStarted) {
    return (
      <div className="h-[70vh] flex flex-col items-center justify-center space-y-8 animate-in fade-in zoom-in duration-1000">
        <div className="text-center space-y-4">
           <div className="w-24 h-24 rounded-[32px] overflow-hidden mx-auto shadow-2xl glow-purple relative group">
              <img 
                src="https://images.unsplash.com/photo-1514525253361-b83f83df915e?q=80&w=300" 
                alt="C.8.L. Music AI" 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
              />
           </div>
           <div className="space-y-1">
             <h1 className="text-6xl font-display font-black tracking-tighter">C.8.L. Music AI</h1>
             <p className="text-[10px] font-black uppercase text-primary tracking-[0.4em]">C.8.L. Universe</p>
           </div>
           <p className="text-white/40 max-w-md mx-auto text-sm uppercase tracking-widest font-bold pt-4">
              Potenciado por {modelName}
           </p>
        </div>

        <GlassCard className="p-10 max-w-2xl w-full text-center space-y-6">
           <div className="flex justify-center gap-8">
              <div className="space-y-1">
                 <p className="text-3xl font-display font-black">{5 - coversToday}</p>
                 <p className="text-[10px] font-black uppercase text-white/30 tracking-widest">Covers Libres Hoy</p>
              </div>
              <div className="w-px h-12 bg-white/5" />
              <div className="space-y-1">
                 <p className="text-3xl font-display font-black text-primary">{userProfile?.plan === 'free' ? 'Básica' : 'Alta'}</p>
                 <p className="text-[10px] font-black uppercase text-white/30 tracking-widest">Calidad de Audio</p>
              </div>
           </div>
           
           <Button 
            className="w-full h-16 text-lg glow-purple"
            onClick={() => setHasStarted(true)}
            icon={Zap}
           >
             Empezar Estudio
           </Button>
           
           <div className="flex items-center justify-center gap-4 text-white/20">
              <Shield size={14} />
              <span className="text-[9px] font-black uppercase tracking-widest">Protegido por Sistema C.8.L. Music AI</span>
           </div>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="space-y-6 lg:space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-1000">
      <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
         <div className="flex items-center gap-4 lg:gap-6">
            <button onClick={() => setHasStarted(false)} className="text-white/20 hover:text-white transition-colors">
               <ChevronDown className="rotate-90" />
            </button>
            <div>
               <h2 className="text-xl lg:text-3xl font-display font-black">Estudio</h2>
               <p className="text-[8px] lg:text-[10px] font-black text-primary uppercase tracking-widest">{modelName}</p>
            </div>
         </div>
         <div className="flex items-center justify-between lg:justify-end gap-6 lg:gap-8">
            <div className="text-right">
               <p className="text-lg lg:text-xl font-display font-black">{coversToday}/5</p>
               <p className="text-[8px] lg:text-[9px] font-black uppercase text-white/40 tracking-widest">Diarios</p>
            </div>
            <Button variant="outline" className="h-10 lg:h-12 border-primary/20 text-primary !text-[10px] lg:!text-xs">Mejorar Plan</Button>
         </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10">
        {/* Left: Input Panel */}
        <div className="lg:col-span-5 space-y-4 lg:space-y-6">
           <GlassCard className="p-3 lg:p-8 space-y-3 lg:space-y-6">
              <div className="relative group/input">
                 <div className="flex items-center justify-between mb-2 lg:mb-3">
                    <label className="text-[9px] lg:text-[10px] font-black text-primary uppercase tracking-[0.2em] block italic">Letra</label>
                    <button 
                      onClick={handleAIRefineLyrics}
                      disabled={isRefiningLyrics}
                      className="p-1.5 rounded-lg bg-primary/10 text-primary hover:bg-primary hover:text-white transition-all group/btn disabled:opacity-50"
                      title="Ayuda de IA para la letra"
                    >
                      {isRefiningLyrics ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} className="group-hover/btn:scale-110 transition-transform" />}
                    </button>
                 </div>
                 <textarea 
                   value={lyricsPrompt}
                   onChange={(e) => setLyricsPrompt(e.target.value)}
                   placeholder="Escribe la letra..."
                   className="w-full bg-white/5 border border-white/5 rounded-xl lg:rounded-2xl p-4 lg:p-6 text-xs lg:text-sm text-white focus:outline-none focus:border-primary/40 focus:bg-white/10 min-h-[150px] lg:min-h-[250px] transition-all"
                 />
              </div>

              <div className="relative group/input">
                 <div className="flex items-center justify-between mb-2 lg:mb-3">
                    <label className="text-[9px] lg:text-[10px] font-black text-secondary uppercase tracking-[0.2em] block italic">Estilo</label>
                    <button 
                      onClick={handleAIRefinePositive}
                      disabled={isRefiningPositive || !positiveStyle.trim()}
                      className="p-1.5 rounded-lg bg-secondary/10 text-secondary hover:bg-secondary hover:text-white transition-all group/btn disabled:opacity-50"
                      title="Refinar estilo con IA"
                    >
                      {isRefiningPositive ? <Loader2 size={14} className="animate-spin" /> : <Wand2 size={14} className="group-hover/btn:scale-110 transition-transform" />}
                    </button>
                 </div>
                 <input 
                   value={positiveStyle}
                   onChange={(e) => setPositiveStyle(e.target.value)}
                   placeholder="Ej: Pop, Rock..."
                   className="w-full bg-white/5 border border-white/5 rounded-xl lg:rounded-2xl p-4 lg:p-5 text-xs lg:text-sm text-white focus:outline-none focus:border-secondary/40 focus:bg-white/10"
                 />
              </div>

              <div className="relative group/input">
                 <div className="flex items-center justify-between mb-2 lg:mb-3">
                    <label className="text-[9px] lg:text-[10px] font-black text-white/30 uppercase tracking-[0.2em] block italic">Negativos</label>
                    <button 
                      onClick={handleAIRefineNegative}
                      disabled={isRefiningNegative || !negativeStyle.trim()}
                      className="p-1.5 rounded-lg bg-white/5 text-white/40 hover:bg-white/10 hover:text-white transition-all group/btn disabled:opacity-50"
                      title="Mejorar prompt negativo"
                    >
                      {isRefiningNegative ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} className="group-hover/btn:scale-110 transition-transform" />}
                    </button>
                 </div>
                 <input 
                   value={negativeStyle}
                   onChange={(e) => setNegativeStyle(e.target.value)}
                   placeholder="Ej: Ruidoso, Sin autotune, Distorsión..."
                   className="w-full bg-white/5 border border-white/5 rounded-2xl p-5 text-sm text-white focus:outline-none focus:border-white/20"
                 />
              </div>

              <div>
                 <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] mb-3 block italic">Título del Proyecto</label>
                 <input 
                   value={title}
                   onChange={(e) => setTitle(e.target.value)}
                   placeholder="Nombre de tu canción..."
                   className="w-full bg-black/20 border border-white/5 rounded-xl p-4 text-xs text-white focus:outline-none focus:border-primary/40"
                 />
              </div>

              <Button 
                fullWidth 
                icon={isGenerating ? Loader2 : Sparkles}
                disabled={isGenerating || !lyricsPrompt.trim()}
                onClick={handleGenerate}
                className={isGenerating ? "animate-pulse glow-purple" : "glow-purple"}
              >
                {isGenerating ? "La IA está trabajando..." : "Generar Canciones (x2)"}
              </Button>
           </GlassCard>
        </div>

        {/* Right: Creation Workspace */}
        <div className="lg:col-span-7 flex flex-col min-h-[400px] lg:h-[800px]">
           <GlassCard className="flex-1 flex flex-col overflow-hidden border-dashed border-white/5 bg-white/[0.01]">
              <div className="p-4 lg:p-8 border-b border-white/5 flex items-center justify-between">
                 <h3 className="text-lg lg:text-xl font-display font-black uppercase tracking-tight">Espacio de Creación</h3>
                 {isGenerating && <div className="text-[10px] font-black text-primary animate-pulse uppercase tracking-[0.2em]">Sincronizando con Servidor...</div>}
              </div>

              <div className="flex-1 flex flex-col items-center justify-center p-4 lg:p-8 relative overflow-hidden">
                 {/* Generation Animation Background */}
                 <AnimatePresence>
                    {isGenerating && (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 z-0 flex items-center justify-center"
                      >
                         <div className="relative w-64 h-64">
                            <div className="absolute inset-0 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
                            <div className="absolute inset-4 rounded-full border-4 border-secondary/20 border-t-secondary animate-spin-slow" />
                            <div className="absolute inset-0 flex items-center justify-center">
                               <Sparkles size={48} className="text-primary animate-pulse" />
                            </div>
                         </div>
                      </motion.div>
                    )}
                 </AnimatePresence>

                 {generatedTracks.length > 0 ? (
                   <div className="w-full space-y-6 z-10 animate-in fade-in zoom-in">
                      <p className="text-center text-[10px] font-black uppercase text-white/30 tracking-[0.5em]">Resultados de Síntesis Horizontal</p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-4">
                         {generatedTracks.map((track) => (
                           <motion.div 
                             key={track.id}
                             whileHover={{ y: -5 }}
                             className="group relative"
                           >
                              <GlassCard className="p-3 lg:p-6 space-y-4 lg:space-y-5 hover:border-primary/40 transition-all border-white/10 relative overflow-hidden">
                                 <div className="flex gap-3 lg:gap-5">
                                    <div className="w-20 h-20 lg:w-24 lg:h-24 shrink-0 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-center relative overflow-hidden group/thumb">
                                       <Music className="text-white/10 w-8 h-8 lg:w-10 lg:h-10" />
                                       <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm">
                                          <button 
                                            onClick={() => handlePlay(track)}
                                            className="w-12 h-12 lg:w-14 lg:h-14 rounded-full bg-primary text-white flex items-center justify-center shadow-xl hover:scale-105 transition-all glow-purple"
                                          >
                                             <Play size={20} className="lg:size-24" fill="currentColor" />
                                          </button>
                                       </div>
                                    </div>
                                    <div className="flex-1 min-w-0 flex flex-col justify-center gap-1">
                                       <div className="flex items-start justify-between gap-2">
                                          <div className="min-w-0">
                                             <h4 className="font-bold text-base lg:text-lg text-white group-hover:text-primary transition-colors truncate leading-tight">{track.title}</h4>
                                             <p className="text-[9px] lg:text-[11px] text-white/40 uppercase font-black tracking-widest truncate">{track.style}</p>
                                          </div>
                                          <div className="relative">
                                             <button 
                                               onClick={() => setActiveMenu(activeMenu === track.id ? null : track.id)}
                                               className="p-1.5 rounded-lg hover:bg-white/10 text-white/40 hover:text-white transition-colors"
                                             >
                                                <MoreVertical size={18} />
                                             </button>

                                             {/* Options Dropdown */}
                                             <AnimatePresence>
                                               {activeMenu === track.id && (
                                                 <>
                                                   <div className="fixed inset-0 z-40" onClick={() => setActiveMenu(null)} />
                                                   <motion.div 
                                                     initial={{ opacity: 0, scale: 0.95, y: 10 }}
                                                     animate={{ opacity: 1, scale: 1, y: 0 }}
                                                     exit={{ opacity: 0, scale: 0.95, y: 10 }}
                                                     className="absolute right-0 top-10 w-56 glass border border-white/10 rounded-2xl p-2 z-50 shadow-2xl backdrop-blur-3xl"
                                                   >
                                                     <div className="grid grid-cols-1 gap-1">
                                                        {[
                                                          { label: 'Extensión', icon: Forward, onClick: () => handleExtension(track) },
                                                          { label: 'Remix IA', icon: RefreshCw, onClick: () => handleRemix(track) },
                                                          { label: 'Videoclip IA', icon: Video, onClick: () => setShowVideoclip(track), color: 'text-indigo-400' },
                                                          { label: 'Reutilización', icon: History, onClick: () => handleReuse(track) },
                                                          { label: 'Pro Studio', icon: Mic2, onClick: () => setShowProStudio(track), color: 'text-yellow-500' },
                                                          { label: 'Descargar MP3', icon: Download, onClick: () => handleDownload(track, 'mp3') },
                                                          { label: 'Descargar WAV', icon: FileAudio, onClick: () => handleDownload(track, 'wav') },
                                                          { label: 'Descargar Vídeo', icon: Video, onClick: () => downloadVideo() },
                                                        ].map((item, idx) => (
                                                          <button 
                                                            key={idx}
                                                            onClick={() => { item.onClick(); setActiveMenu(null); }}
                                                            className={`flex items-center gap-3 w-full p-3 rounded-xl hover:bg-white/10 text-[10px] font-black uppercase tracking-widest transition-all ${item.color || 'text-white'}`}
                                                          >
                                                             <item.icon size={14} />
                                                             {item.label}
                                                          </button>
                                                        ))}
                                                     </div>
                                                   </motion.div>
                                                 </>
                                               )}
                                             </AnimatePresence>
                                          </div>
                                       </div>

                                       <div className="flex items-center gap-4 mt-1">
                                          <div className="flex items-center gap-1">
                                             <button 
                                               onClick={() => handleFeedback(track.id, 'up')}
                                               className={`p-1.5 rounded-lg transition-colors ${trackFeedback[track.id] === 'up' ? 'text-primary bg-primary/10' : 'text-white/20 hover:text-white'}`}
                                             >
                                                <ThumbsUp size={14} />
                                             </button>
                                             <button 
                                               onClick={() => handleFeedback(track.id, 'down')}
                                               className={`p-1.5 rounded-lg transition-colors ${trackFeedback[track.id] === 'down' ? 'text-red-400 bg-red-400/10' : 'text-white/20 hover:text-white'}`}
                                             >
                                                <ThumbsDown size={14} />
                                             </button>
                                          </div>
                                          <div className="h-0.5 flex-1 bg-white/5 rounded-full overflow-hidden">
                                             <div className="h-full bg-primary/40 w-1/4 animate-pulse" />
                                          </div>
                                          <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">3:24</span>
                                       </div>
                                    </div>
                                 </div>

                                 <div className="pt-4 border-t border-white/5 flex gap-2">
                                    <Button 
                                      variant="outline" 
                                      fullWidth 
                                      icon={Share2} 
                                      className="!text-[9px] !py-2.5 flex-1 !rounded-xl"
                                      onClick={() => handleShare(track)}
                                    >
                                      Compartir
                                    </Button>
                                    <button 
                                      onClick={() => handleSave(track)}
                                      disabled={savingTrackId === track.id || savedTracks.includes(track.id)}
                                      className={`flex items-center justify-center gap-2 h-10 px-4 rounded-xl flex-1 transition-all text-[9px] font-black uppercase tracking-widest border border-white/10
                                        ${savedTracks.includes(track.id) ? 'bg-green-500/10 text-green-500 border-green-500/20' : 'bg-white/5 text-white hover:bg-white/10'}
                                      `}
                                    >
                                       {savingTrackId === track.id ? <Loader2 size={14} className="animate-spin" /> : (savedTracks.includes(track.id) ? <Check size={14} /> : <Star size={14} />)}
                                       {savedTracks.includes(track.id) ? 'Guardado' : 'Guardar'}
                                    </button>
                                 </div>
                              </GlassCard>
                           </motion.div>
                         ))}
                      </div>
                      
                      <div className="pt-10 flex justify-center">
                         <Button variant="outline" onClick={() => setGeneratedTracks([])} className="border-white/10 text-white/40 hover:text-white">Nueva Creación</Button>
                      </div>
                   </div>
                 ) : !isGenerating && (
                    <div className="text-center space-y-6 opacity-30">
                       <Database size={64} className="mx-auto" />
                       <div className="space-y-1">
                          <h4 className="text-xl font-display font-black uppercase">Buffer Vacío</h4>
                          <p className="text-xs max-w-xs mx-auto">Ingresa los parámetros a la izquierda para ver cómo la IA ejecuta tu visión musical.</p>
                       </div>
                    </div>
                 )}
              </div>
           </GlassCard>
        </div>
      </div>

      <AnimatePresence>
        {showVideoclip && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-2xl flex flex-col items-center justify-center p-4 lg:p-8"
          >
             <button 
               onClick={() => {
                 setShowVideoclip(null);
                 setUploadedImage(null);
                 setVideoFinished(false);
                 setVideoProgress(0);
               }} 
               className="absolute top-6 right-6 lg:top-10 lg:right-10 text-white/40 hover:text-white z-10 p-2"
             >
                <X size={32} />
             </button>

             <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                {/* Left: Input & Upload */}
                <div className="space-y-6 lg:order-1 order-2">
                   <div className="space-y-2">
                      <h3 className="text-3xl lg:text-4xl font-display font-black uppercase tracking-tighter">AI Videoclip Master</h3>
                      <p className="text-primary font-black uppercase tracking-[0.4em] text-[10px]">Sincronizando: {showVideoclip.title}</p>
                   </div>
                   
                   {!videoFinished ? (
                     <GlassCard className="p-6 border-dashed border-white/10 space-y-4">
                        <p className="text-xs text-white/60">Sube una foto o viñeta para usar como referencia visual para tu videoclip. Nuestra IA generará movimiento y efectos basados en el ritmo de tu canción.</p>
                        
                        <div className="relative group">
                           {uploadedImage ? (
                             <div className="relative aspect-video rounded-xl overflow-hidden mt-2">
                                <img src={uploadedImage} className="w-full h-full object-cover" alt="Referencia" />
                                <button 
                                  onClick={() => setUploadedImage(null)}
                                  className="absolute top-2 right-2 bg-black/60 p-1.5 rounded-full text-white hover:bg-red-500 transition-colors"
                                >
                                   <X size={14} />
                                </button>
                             </div>
                           ) : (
                             <label className="flex flex-col items-center justify-center aspect-video rounded-xl bg-white/5 border border-dashed border-white/20 hover:border-primary/50 hover:bg-white/10 transition-all cursor-pointer">
                                <Upload size={32} className="text-white/20 mb-3" />
                                <span className="text-[10px] font-black uppercase tracking-widest text-white/40 group-hover:text-white transition-colors">Seleccionar Foto de Álbum</span>
                                <input type="file" accept="image/*" className="hidden" onChange={handleVideoUpload} />
                             </label>
                           )}
                        </div>

                        <Button 
                          fullWidth 
                          disabled={!uploadedImage || isVideoGenerating}
                          onClick={startVideoGeneration}
                          icon={isVideoGenerating ? Loader2 : Sparkles}
                          className={isVideoGenerating ? "animate-pulse" : ""}
                        >
                           {isVideoGenerating ? `Procesando Arte Visual ${videoProgress}%` : "Generar Videoclip IA"}
                        </Button>
                     </GlassCard>
                   ) : (
                     <div className="space-y-4 animate-in slide-in-from-left-4">
                        <div className="bg-green-500/10 border border-green-500/20 p-4 rounded-xl flex items-center gap-3">
                           <Check className="text-green-500" />
                           <span className="text-xs font-bold text-green-500 uppercase tracking-widest">¡Videoclip Listo para Descargar!</span>
                        </div>
                        <Button fullWidth icon={Download} onClick={downloadVideo}>Descargar a mi Dispositivo</Button>
                        <Button variant="outline" fullWidth onClick={() => setVideoFinished(false)}>Crear Otra Versión</Button>
                     </div>
                   )}
                </div>

                {/* Right: Preview Player */}
                <div className="lg:order-2 order-1">
                   <div className="w-full aspect-video rounded-3xl overflow-hidden shadow-[0_0_100px_rgba(var(--primary),0.3)] relative border border-white/10 bg-black">
                      {isVideoGenerating ? (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-center space-y-6">
                           <div className="relative">
                              <Video size={60} className="text-white/20 animate-bounce" />
                              <div className="absolute inset-0 glow-purple blur-2xl opacity-20" />
                           </div>
                           <div className="w-48 h-1 bg-white/10 rounded-full overflow-hidden">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${videoProgress}%` }}
                                className="h-full bg-primary"
                              />
                           </div>
                        </div>
                      ) : (
                        <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/40 via-purple-900/40 to-black">
                           {uploadedImage && <img src={uploadedImage} className="w-full h-full object-cover opacity-50 grayscale hover:grayscale-0 transition-all duration-1000" alt="Preview" />}
                           <div className="absolute inset-0 flex items-center justify-center p-8 bg-black/20">
                             {!uploadedImage && (
                               <div className="text-center group">
                                  <Video size={80} className="mx-auto text-white/10 mb-6 group-hover:text-primary/20 transition-colors" />
                                  <p className="text-[10px] font-black uppercase text-white/30 tracking-[0.5em]">Esperando Referencia Visual</p>
                               </div>
                             )}
                             {videoFinished && (
                               <motion.button 
                                 initial={{ scale: 0.8, opacity: 0 }}
                                 animate={{ scale: 1, opacity: 1 }}
                                 onClick={() => handlePlay(showVideoclip)}
                                 className="w-20 h-20 rounded-full bg-white text-black flex items-center justify-center shadow-2xl hover:scale-110 transition-transform group/play"
                               >
                                  <Play fill="currentColor" size={32} className="group-hover/play:scale-110 transition-transform" />
                               </motion.button>
                             )}
                           </div>
                        </div>
                      )}
                   </div>
                </div>
             </div>
             <p className="mt-8 text-white/40 text-[8px] lg:text-xs font-black uppercase tracking-widest italic text-center max-w-sm">
                Nuestra arquitectura sincroniza los picos de audio con el desplazamiento de píxeles para una experiencia cinematográfica.
             </p>
          </motion.div>
        )}
        {showProStudio && (
          <ProStudio 
            track={showProStudio} 
            onClose={() => setShowProStudio(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

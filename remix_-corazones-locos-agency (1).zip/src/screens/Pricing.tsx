import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Check, Star, Zap, ShieldCheck, Sparkles, Mic2, Video, CreditCard, Shield, Database, X, Lock, Loader2 } from "lucide-react";
import { doc, updateDoc } from "firebase/firestore";

import { GlassCard, Button } from "../components/UI";
import { auth, db, handleFirestoreError, OperationType } from "../lib/firebase";

export default function Pricing({ onNavigate }: { onNavigate?: (screen: any) => void }) {
  const [selectedPlan, setSelectedPlan] = useState<any | null>(null);
  const [showExitOffer, setShowExitOffer] = useState(false);
  const [offerAccepted, setOfferAccepted] = useState(false);
  const [currency, setCurrency] = useState<'USD' | 'EUR'>('EUR');
  const [billingCycle, setBillingCycle] = useState<'weekly' | 'monthly' | 'yearly'>('monthly');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal'>('card');
  const [isProcessing, setIsProcessing] = useState(false);

  // Trigger exit offer when trying to "go back"
  const handleBack = () => {
    if (!offerAccepted && !showExitOffer) {
      setShowExitOffer(true);
    } else if (onNavigate) {
      onNavigate('home');
    }
  };

  const getPrice = (planId: string) => {
    // Base prices in EUR (Monthly)
    let basePrice = 0;
    if (planId === 'free') return '0.00';
    if (planId === 'standard') basePrice = 9.95;
    if (planId === 'premium') basePrice = 31.95;

    // Exit Intent Special Offer (6.95 first month)
    if (offerAccepted && planId === 'standard' && billingCycle === 'monthly') {
      return '6.95';
    }

    // Adjust for Currency
    let adjustedPrice = basePrice;
    if (currency === 'USD') {
      adjustedPrice = planId === 'standard' ? 10.95 : 34.95;
    }

    // Adjust for Cycle
    if (billingCycle === 'weekly') {
      return (adjustedPrice / 3.5).toFixed(2);
    } else if (billingCycle === 'yearly') {
      // 2 months free (basePrice * 10) + EXTRA 5% DISCOUNT
      return ((adjustedPrice * 10) * 0.95).toFixed(2);
    }

    return adjustedPrice.toFixed(2);
  };

  const symbol = currency === 'EUR' ? '€' : '$';
  const cycleLabel = billingCycle === 'weekly' ? '/sem' : billingCycle === 'yearly' ? '/año' : '/mes';

  const plans = [
    {
      id: "free",
      name: "Free Creator",
      price: "0",
      description: "Entrada básica para nuevos talentos AI.",
      credits: "50",
      aiVersion: "Engine v3.5",
      features: [
        "5 Canciones diarias (10 cred/ea)",
        "Motor AI v3.5 (Esencial)",
        "Calidad Estándar Digital",
        "Textura Vocal Básica",
        "Sin generador de Video",
        "Publicidad Ocasional"
      ],
      button: "Plan Activo",
      variant: "outline" as const
    },
    {
      id: "standard",
      name: "Standard Studio",
      price: "9.95",
      description: "Para productores que buscan calidad competitiva.",
      credits: "2.500",
      aiVersion: "Engine v4.5",
      features: [
        "250 Canciones (Regen ilimitada)",
        "Motor AI v4.5 (Avanzado)",
        "Calidad Hi-Fi Studio",
        "Vibratos y Armónicos Reales",
        "Video por suplemento",
        "Sin Anuncios"
      ],
      button: "Elegir Standard",
      variant: "primary" as const,
      popular: true
    },
    {
      id: "premium",
      name: "Master Premium",
      price: "31.95",
      description: "Infinito potencial creativo y producción total.",
      credits: "10.000",
      aiVersion: "Engine v5.5 (Supreme)",
      features: [
        "Acceso Ilimitado Creador",
        "Motor AI v5.5 (Supreme Gold)",
        "Texturas Vocales Ultrarrealistas",
        "Generador de Video 4K Incluido",
        "Acceso a Studio Mixer Pro",
        "Soporte Prioritario 24/7"
      ],
      button: "Master Pro",
      variant: "secondary" as const,
      icon: Star
    }
  ];

  const handleUpgrade = async () => {
    if (!auth.currentUser) {
      alert("Por favor, inicia sesión para cambiar de plan.");
      return;
    }
    
    setIsProcessing(true);
    const path = `users/${auth.currentUser.uid}`;
    
    // Map plans to credits and AI version
    const planConfig: any = {
      free: { credits: 50, aiVersion: "3.5" },
      standard: { credits: 2500, aiVersion: "4.5" },
      premium: { credits: 10000, aiVersion: "5.5" }
    };

    try {
      await updateDoc(doc(db, path), {
        plan: selectedPlan.id,
        credits: planConfig[selectedPlan.id].credits,
        aiVersion: planConfig[selectedPlan.id].aiVersion
      });
      setIsProcessing(false);
      setSelectedPlan(null);
      alert(`¡Suscripción ${selectedPlan.name} activada con éxito!`);
    } catch (error) {
      setIsProcessing(false);
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  return (
    <div className="space-y-16 py-12">
      {/* Navigation Header */}
      <div className="flex justify-start">
        <button 
          onClick={handleBack}
          className="flex items-center gap-2 text-white/40 hover:text-white transition-colors group"
        >
          <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-primary group-hover:text-black transition-all">
             <X size={16} />
          </div>
          <span className="text-[10px] font-black uppercase tracking-widest">Cerrar</span>
        </button>
      </div>

      <section className="text-center space-y-8">
        <div className="space-y-4">
          <h1 className="text-5xl md:text-7xl font-display font-black leading-tight">
            Escala tu <span className="gradient-text">Frecuencia.</span>
          </h1>
          {offerAccepted && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-primary/20 border border-primary/40 px-6 py-2 rounded-2xl inline-block"
            >
              <p className="text-primary text-xs font-black uppercase tracking-widest">
                ¡Oferta Activada: 1 Semana Gratis + Primer Mes 6.95€!
              </p>
            </motion.div>
          )}
          <p className="text-white/60 text-lg max-w-2xl mx-auto">
            Elige la potencia de tu motor de inteligencia musical y desbloquea texturas sonoras inalcanzables.
          </p>
        </div>

        {/* Billing Cycle Selector */}
        <div className="flex justify-center pt-4">
          <div className="bg-white/5 border border-white/10 p-1 rounded-2xl flex gap-1">
            {[
              { id: 'weekly', label: 'Semanal' },
              { id: 'monthly', label: 'Mensual' },
              { id: 'yearly', label: 'Anual' }
            ].map(cycle => (
              <button
                key={cycle.id}
                onClick={() => setBillingCycle(cycle.id as any)}
                className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${billingCycle === cycle.id ? 'bg-primary text-white glow-purple' : 'text-white/40 hover:text-white'}`}
              >
                {cycle.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className="flex"
          >
            <GlassCard className={`p-8 flex flex-col justify-between relative flex-1 transition-all hover:scale-[1.02] ${plan.id === 'premium' ? 'glass-premium shadow-[0_0_50px_rgba(247,81,161,0.15)] overflow-hidden' : ''} ${plan.popular ? 'border-primary/40 ring-1 ring-primary/20 bg-primary/5' : ''}`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary px-6 py-1 rounded-full text-[10px] font-black uppercase tracking-widest text-black shadow-xl glow-purple">
                  Más Popular
                </div>
              )}
              
              <div className="space-y-8">
                <div>
                  <div className="flex justify-between items-start">
                    <span className={`text-[10px] font-black uppercase tracking-widest ${plan.id === 'premium' ? 'text-tertiary' : 'text-white/40'}`}>
                      {plan.id === 'free' ? 'Básico' : plan.id === 'standard' ? 'Fanático' : 'Pro Studio'}
                    </span>
                    <div className="bg-white/5 p-2 rounded-lg">
                       {plan.icon ? <plan.icon className="text-tertiary" size={20} /> : <Sparkles className="text-primary" size={20} />}
                    </div>
                  </div>
                  <h3 className="text-3xl font-display font-black mt-2">{plan.name}</h3>
                  <div className="mt-6 flex items-baseline gap-1">
                    <span className="text-5xl font-black tracking-tighter">{symbol}{getPrice(plan.id)}</span>
                    <span className="text-white/40 text-sm uppercase font-black">{cycleLabel}</span>
                  </div>
                  <div className="mt-4 flex items-center gap-2 text-[10px] font-bold text-primary uppercase tracking-widest bg-primary/10 w-fit px-3 py-1 rounded-full border border-primary/20">
                    <Zap size={10} /> {plan.credits} Créditos
                  </div>
                </div>

                <div className="py-4 border-y border-white/5">
                   <p className="text-[10px] text-white/40 uppercase tracking-widest mb-2 font-bold flex items-center gap-2">
                     <Mic2 size={12} /> Motor de Síntesis
                   </p>
                   <p className="text-lg font-display font-black gradient-text">{plan.aiVersion}</p>
                </div>

                <ul className="space-y-4">
                  {plan.features.map((feature, j) => (
                    <li key={j} className="flex items-start gap-3 text-sm">
                      <div className="mt-1 rounded-full bg-secondary/20 p-0.5">
                        <Check size={12} className="text-secondary" />
                      </div>
                      <span className="text-white/70 leading-snug">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-10">
                <Button 
                  variant={plan.id === 'premium' ? 'premium' : plan.variant} 
                  fullWidth 
                  className={plan.popular ? 'scale-105' : ''}
                  onClick={() => plan.id === 'free' ? null : setSelectedPlan(plan)}
                >
                  {plan.button}
                </Button>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      {/* Exit Intent Offer Modal */}
      <AnimatePresence>
        {showExitOffer && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/95 backdrop-blur-2xl"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-lg glass-premium p-10 text-center space-y-8 rounded-[40px] border border-primary/20 shadow-[0_0_100px_rgba(247,81,161,0.2)]"
            >
              <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto text-primary glow-purple animate-bounce">
                <Sparkles size={40} />
              </div>
              <div className="space-y-4">
                <h2 className="text-4xl font-display font-black tracking-tighter uppercase italic">¡Espera! No te vayas ahora</h2>
                <p className="text-white/60 text-lg">Queremos que pruebes el poder de nuestra AI sin riesgos.</p>
              </div>
              
              <div className="bg-white/5 border border-white/10 rounded-3xl p-6 space-y-4">
                 <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-white/40 uppercase tracking-widest">Oferta Especial</span>
                    <span className="bg-primary text-black text-[10px] font-black px-3 py-1 rounded-full uppercase">Limitado</span>
                 </div>
                 <div className="flex justify-center items-center gap-4">
                    <div className="text-center">
                       <p className="text-3xl font-display font-black">1 SEMANA</p>
                       <p className="text-[10px] font-bold text-primary uppercase">GRATIS</p>
                    </div>
                    <div className="h-10 w-[1px] bg-white/10" />
                    <div className="text-center">
                       <p className="text-3xl font-display font-black">6.95€</p>
                       <p className="text-[10px] font-bold text-white/40 uppercase">PRIMER MES</p>
                    </div>
                 </div>
              </div>

              <div className="space-y-3">
                <Button 
                  fullWidth 
                  onClick={() => {
                    setOfferAccepted(true);
                    setShowExitOffer(false);
                    setBillingCycle('monthly');
                  }}
                  className="bg-primary text-black font-black uppercase text-xs py-5 glow-purple"
                >
                  Sí, quiero la oferta
                </Button>
                <button 
                  onClick={() => onNavigate?.('home')}
                  className="text-[10px] font-black text-white/20 hover:text-white transition-colors uppercase tracking-widest pt-2"
                >
                  No gracias, prefiero irme
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Payment Modal */}
      <AnimatePresence>
        {selectedPlan && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/90 backdrop-blur-xl"
              onClick={() => setSelectedPlan(null)}
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-xl bg-[#0a0a0a] border border-white/10 rounded-[40px] shadow-2xl overflow-hidden flex flex-col md:flex-row"
            >
              {/* Checkout Sidebar */}
              <div className="bg-white/5 p-8 md:w-1/3 flex flex-col justify-between border-r border-white/5">
                <div className="space-y-6">
                   <div className="w-12 h-12 rounded-2xl bg-primary flex items-center justify-center shadow-lg glow-purple">
                      <CreditCard className="text-white" size={24} />
                   </div>
                   <div className="space-y-1">
                      <p className="text-[10px] font-black uppercase text-white/40 tracking-widest">Resumen</p>
                      <h4 className="text-2xl font-display font-black uppercase leading-tight">{selectedPlan.name}</h4>
                   </div>
                </div>
                <div className="space-y-4 pt-8">
                  <div className="flex justify-between items-end border-b border-white/5 pb-4">
                    <span className="text-xs text-white/40 font-bold uppercase">Total ({billingCycle})</span>
                    <span className="text-3xl font-display font-black text-primary">{symbol}{getPrice(selectedPlan.id)}</span>
                  </div>
                  <div className="flex gap-2">
                     <button 
                       onClick={() => setCurrency('EUR')}
                       className={`flex-1 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${currency === 'EUR' ? 'bg-white text-black' : 'bg-white/5 text-white/40'}`}
                     >EUR</button>
                     <button 
                       onClick={() => setCurrency('USD')}
                       className={`flex-1 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${currency === 'USD' ? 'bg-white text-black' : 'bg-white/5 text-white/40'}`}
                     >USD</button>
                  </div>
                  {currency === 'USD' && (
                    <p className="text-[8px] text-primary/60 font-black uppercase tracking-widest text-center mt-2 animate-pulse">
                      Tasa de Cambio: 1 EUR ≈ 1.10 USD
                    </p>
                  )}
                </div>
              </div>

              {/* Main Checkout Form */}
              <div className="flex-1 p-8 space-y-6">
                <div className="flex justify-between items-center">
                   <h3 className="text-xl font-bold font-display uppercase italic tracking-tighter">Pasarela de Pago</h3>
                   <button onClick={() => setSelectedPlan(null)} className="text-white/20 hover:text-white transition-colors">
                      <X size={20} />
                   </button>
                </div>

                <div className="flex gap-4">
                   <button 
                     onClick={() => setPaymentMethod('card')}
                     className={`flex-1 p-4 rounded-2xl border transition-all flex items-center justify-center gap-3 ${paymentMethod === 'card' ? 'bg-primary/10 border-primary text-primary' : 'bg-white/5 border-white/5 text-white/40'}`}
                   >
                      <CreditCard size={18} />
                      <span className="text-[10px] font-black uppercase">Tarjeta</span>
                   </button>
                   <button 
                     onClick={() => setPaymentMethod('paypal')}
                     className={`flex-1 p-4 rounded-2xl border transition-all flex items-center justify-center gap-3 ${paymentMethod === 'paypal' ? 'bg-blue-500/10 border-blue-500 text-blue-500' : 'bg-white/5 border-white/5 text-white/40'}`}
                   >
                      <Zap size={18} />
                      <span className="text-[10px] font-black uppercase">PayPal</span>
                   </button>
                </div>

                {paymentMethod === 'card' ? (
                  <div className="space-y-4 animate-in fade-in zoom-in-95 duration-300">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-white/40 tracking-widest pl-2">Titular de la Tarjeta</label>
                       <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-sm focus:outline-none focus:border-primary transition-all uppercase font-display" placeholder="NOMBRE COMPLETO" />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-white/40 tracking-widest pl-2">Número de Tarjeta</label>
                       <div className="relative">
                          <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl p-3 pr-12 text-sm focus:outline-none focus:border-primary transition-all font-mono" placeholder="4532 **** **** ****" />
                          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex gap-1">
                             <div className="w-6 h-4 bg-red-500/80 rounded shrink-0" />
                             <div className="w-6 h-4 bg-orange-500/80 rounded shrink-0" />
                          </div>
                       </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase text-white/40 tracking-widest pl-2">Caducidad</label>
                         <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-sm focus:outline-none focus:border-primary transition-all font-mono" placeholder="MM/YY" />
                      </div>
                      <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase text-white/40 tracking-widest pl-2">CVC</label>
                         <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-sm focus:outline-none focus:border-primary transition-all font-mono" placeholder="***" />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center p-8 space-y-4 bg-blue-500/5 rounded-2xl border border-blue-500/10 animate-in fade-in zoom-in-95 duration-300">
                    <Zap size={40} className="text-blue-500 animate-pulse" />
                    <p className="text-xs font-bold text-center text-white/60 leading-relaxed">Serás redirigido a la pasarela segura de <span className="text-blue-500">PayPal</span> para completar tu suscripción mensual de forma rápida y segura.</p>
                  </div>
                )}

                <div className="pt-6">
                  <Button 
                    fullWidth 
                    disabled={isProcessing}
                    onClick={handleUpgrade}
                    icon={isProcessing ? Loader2 : Lock}
                    className={isProcessing ? "animate-pulse" : ""}
                  >
                    {isProcessing ? "Procesando..." : `Confirmar Pago • ${symbol}${getPrice(selectedPlan.id)}`}
                  </Button>
                  <p className="text-[8px] text-white/20 text-center mt-4 font-black uppercase tracking-widest">Al confirmar, aceptas los términos de servicio de C.8.L. Universe • Pago 100% Seguro</p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <section className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <GlassCard className="p-8 flex items-center gap-6 border-l-4 border-l-primary bg-primary/5">
          <div className="p-4 rounded-2xl bg-primary/10 text-primary">
            <Video size={32} />
          </div>
          <div>
            <h4 className="font-black text-lg">Pases de Video</h4>
            <p className="text-white/40 text-xs">Paga solo por lo que necesites. 10 videos extra por €4.99.</p>
          </div>
        </GlassCard>
        <GlassCard className="p-8 flex items-center gap-6 border-l-4 border-l-secondary bg-secondary/5">
          <div className="p-4 rounded-2xl bg-secondary/10 text-secondary">
            <ShieldCheck size={32} />
          </div>
          <div>
            <h4 className="font-black text-lg">Garantía Royalties</h4>
            <p className="text-white/40 text-xs">Mantén el 100% de tus derechos en planes Studio y Master.</p>
          </div>
        </GlassCard>
        <GlassCard className="p-8 flex items-center gap-6 border-l-4 border-l-tertiary bg-tertiary/5">
          <div className="p-4 rounded-2xl bg-tertiary/10 text-tertiary">
            <Zap size={32} />
          </div>
          <div>
            <h4 className="font-black text-lg">Batch Processing</h4>
            <p className="text-white/40 text-xs">Genera hasta 10 variaciones simultáneas en el plan Master Pro.</p>
          </div>
        </GlassCard>
      </section>
    </div>
  );
}

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Settings, 
  MapPin, 
  Globe, 
  Star, 
  Edit3, 
  Music, 
  Play, 
  History, 
  User as UserIcon,
  LogOut,
  ChevronRight,
  Shield,
  Save,
  X,
  Plus
} from "lucide-react";
import { doc, onSnapshot, updateDoc, collection, query, where, orderBy, serverTimestamp } from "firebase/firestore";
import { auth, db, handleFirestoreError, OperationType, logout } from "../lib/firebase";
import { GlassCard, Button } from "../components/UI";

interface SongRecord {
  id: string;
  title: string;
  artist: string;
  thumbnailUrl: string;
  createdAt: any;
  views?: number;
}

export default function Profile() {
  const [profile, setProfile] = useState<any>(null);
  const [songs, setSongs] = useState<SongRecord[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    displayName: "",
    bio: "",
    nationality: "",
    residence: "",
    zodiacSign: ""
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!auth.currentUser) return;

    // Profile listener
    const unsubProfile = onSnapshot(doc(db, "users", auth.currentUser.uid), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setProfile(data);
        setEditData({
          displayName: data.displayName || "",
          bio: data.bio || "",
          nationality: data.nationality || "",
          residence: data.residence || "",
          zodiacSign: data.zodiacSign || ""
        });
      }
      setIsLoading(false);
    }, (error) => handleFirestoreError(error, OperationType.GET, `users/${auth.currentUser?.uid}`));

    // Songs listener (Oldest to Newest)
    const songsQuery = query(
      collection(db, "songs"),
      where("ownerId", "==", auth.currentUser.uid),
      orderBy("createdAt", "asc")
    );

    const unsubSongs = onSnapshot(songsQuery, (snap) => {
      setSongs(snap.docs.map(d => ({ id: d.id, ...d.data() })) as SongRecord[]);
    }, (error) => handleFirestoreError(error, OperationType.LIST, "songs"));

    return () => {
      unsubProfile();
      unsubSongs();
    };
  }, []);

  const handleUpdateProfile = async () => {
    if (!auth.currentUser) return;
    try {
      await updateDoc(doc(db, "users", auth.currentUser.uid), {
        ...editData,
        updatedAt: serverTimestamp()
      });
      setIsEditing(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${auth.currentUser.uid}`);
    }
  };

  if (isLoading) {
    return (
      <div className="h-[60vh] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!auth.currentUser || !profile) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center space-y-6 text-center">
        <div className="p-6 rounded-full bg-white/5 text-white/20">
           <Shield size={64} strokeWidth={1} />
        </div>
        <div className="space-y-2">
           <h2 className="text-2xl font-display font-black uppercase tracking-widest">Acceso Restringido</h2>
           <p className="text-white/40 text-sm max-w-xs mx-auto">Debes iniciar sesión para ver tu perfil de creador.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Header Profile Section */}
      <section className="relative">
        <div className="h-64 rounded-[40px] overflow-hidden relative border border-white/5 group">
           {/* Background Video Simulator or Moving Gradient */}
           <div className="absolute inset-0 bg-gradient-to-tr from-primary/30 via-tertiary/20 to-black animate-gradient-slow" />
           <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />
           
           <div className="absolute bottom-10 left-10 flex items-end gap-10">
              <div className="relative group">
                 <div className="w-40 h-40 rounded-[32px] overflow-hidden border-4 border-white/10 shadow-2xl group-hover:scale-105 transition-transform duration-500">
                    {profile.avatarVideoUrl ? (
                      <video 
                        src={profile.avatarVideoUrl} 
                        autoPlay 
                        loop 
                        muted 
                        playsInline
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <img 
                        src={auth.currentUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${auth.currentUser.uid}`} 
                        className="w-full h-full object-cover" 
                        alt="Avatar" 
                      />
                    )}
                 </div>
                 <div className="absolute -bottom-2 -right-2 w-10 h-10 rounded-2xl bg-primary flex items-center justify-center text-white border-4 border-black group-hover:rotate-12 transition-transform cursor-pointer">
                    <Edit3 size={16} />
                 </div>
              </div>

              <div className="space-y-4 pb-2">
                 <div className="space-y-1">
                    <p className="text-[10px] font-black text-primary uppercase tracking-[0.3em]">ID: {profile.uid.slice(0, 10).toUpperCase()}</p>
                    <h1 className="text-6xl font-display font-black tracking-tighter">{profile.displayName}</h1>
                 </div>
                 
                 <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2 text-white/60">
                       <History size={14} className="text-secondary" />
                       <span className="text-xs font-bold uppercase tracking-widest">Unido {new Date(profile.createdAt?.toDate?.() || Date.now()).toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}</span>
                    </div>
                    <div className="flex items-center gap-2 text-white/60">
                       <Music size={14} className="text-primary" />
                       <span className="text-xs font-bold uppercase tracking-widest">{songs.length} Covers Totales</span>
                    </div>
                 </div>
              </div>
           </div>

           <div className="absolute top-10 right-10 flex gap-4">
              <Button 
                variant="outline" 
                icon={Settings} 
                className="!bg-black/40 !backdrop-blur-xl !border-white/10"
                onClick={() => setIsEditing(true)}
              >
                Editar Perfil
              </Button>
              <Button 
                variant="outline" 
                className="!bg-red-500/10 !border-red-500/20 !text-red-500 hover:!bg-red-500 hover:!text-white"
                onClick={logout}
                icon={LogOut}
              >
                Salir
              </Button>
           </div>
        </div>
      </section>

      {/* Info & Bio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-4 space-y-8">
           <GlassCard className="p-8 space-y-8">
              <div className="space-y-6">
                 <h3 className="text-xl font-display font-black uppercase tracking-widest text-white/40 border-b border-white/5 pb-4">Detalles Personales</h3>
                 
                 <div className="space-y-6">
                    <div className="flex items-center gap-4">
                       <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                          <Globe size={18} />
                       </div>
                       <div>
                          <p className="text-[10px] font-black text-white/30 uppercase tracking-widest">Nacionalidad</p>
                          <p className="font-bold">{profile.nationality || "No especificada"}</p>
                       </div>
                    </div>

                    <div className="flex items-center gap-4">
                       <div className="w-10 h-10 rounded-xl bg-secondary/10 flex items-center justify-center text-secondary">
                          <MapPin size={18} />
                       </div>
                       <div>
                          <p className="text-[10px] font-black text-white/30 uppercase tracking-widest">Residencia</p>
                          <p className="font-bold">{profile.residence || "No especificada"}</p>
                       </div>
                    </div>

                    <div className="flex items-center gap-4">
                       <div className="w-10 h-10 rounded-xl bg-tertiary/10 flex items-center justify-center text-tertiary">
                          <Star size={18} />
                       </div>
                       <div>
                          <p className="text-[10px] font-black text-white/30 uppercase tracking-widest">Signo Zodiacal</p>
                          <p className="font-bold">{profile.zodiacSign || "No especificado"}</p>
                       </div>
                    </div>
                 </div>
              </div>

              <div className="space-y-4">
                 <h3 className="text-xl font-display font-black uppercase tracking-widest text-white/40 border-b border-white/5 pb-4">Nivel de Cuenta</h3>
                 <div className="p-4 rounded-2xl bg-gradient-to-tr from-primary/20 to-tertiary/20 border border-white/10 flex items-center justify-between">
                    <div>
                       <p className="text-xs font-black uppercase text-primary tracking-widest">{profile.plan}</p>
                       <p className="text-[10px] text-white/40 uppercase">Plan Actual</p>
                    </div>
                    <ChevronRight className="text-white/20" />
                 </div>
              </div>
           </GlassCard>
        </div>

        <div className="lg:col-span-8 flex flex-col">
           <GlassCard className="p-10 flex-1 space-y-8 border-primary/10">
              <div className="flex items-center justify-between">
                 <h2 className="text-3xl font-display font-black uppercase tracking-tight">Reconocimiento</h2>
                 <div className="w-12 h-1 bg-primary/20 rounded-full" />
              </div>

              <div className="space-y-6">
                 <div className="relative group">
                    <p className="text-lg text-white/70 leading-relaxed italic font-medium">
                       "{profile.bio || "Este creador aún no ha definido su visión artística. Haz clic en 'Editar Perfil' para empezar a escribir tu historia en C.8.L. Music AI."}"
                    </p>
                    <div className="absolute -left-6 top-0 text-primary/20 text-6xl font-display">"</div>
                 </div>

                 <div className="pt-8 border-t border-white/5 grid grid-cols-3 gap-6 text-center">
                    <div>
                       <p className="text-2xl font-display font-black text-white">{profile.referredCount || 0}</p>
                       <p className="text-[10px] font-black uppercase text-white/30 tracking-widest">Colegas</p>
                    </div>
                    <div>
                       <p className="text-2xl font-display font-black text-white">{(profile.credits / 100).toFixed(1)}k</p>
                       <p className="text-[10px] font-black uppercase text-white/30 tracking-widest">Energía</p>
                    </div>
                    <div>
                       <p className="text-2xl font-display font-black text-white">{profile.aiVersion}</p>
                       <p className="text-[10px] font-black uppercase text-white/30 tracking-widest">AI Sync</p>
                    </div>
                 </div>
              </div>
           </GlassCard>
        </div>
      </div>

      {/* Songs Section - Oldest to Newest */}
      <section className="space-y-8 pt-12 border-t border-white/5">
        <div className="flex items-center justify-between">
           <div>
              <h2 className="text-4xl font-display font-black uppercase tracking-tight">Tu Trayectoria</h2>
              <p className="text-white/40 text-xs font-bold uppercase tracking-widest mt-1">Colección desde tus inicios</p>
           </div>
           <div className="flex gap-4">
              <div className="flex items-center gap-2 text-primary bg-primary/10 px-4 py-2 rounded-xl border border-primary/20">
                 <History size={16} />
                 <span className="text-[10px] font-black uppercase tracking-widest">Cronología Ascendente</span>
              </div>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
           {songs.length > 0 ? songs.map((song, i) => (
              <motion.div 
                key={song.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.05 }}
              >
                <GlassCard className="group overflow-hidden relative cursor-pointer hover:border-primary/40 transition-all duration-500">
                   <div className="aspect-square relative overflow-hidden">
                      <img 
                        src={song.thumbnailUrl || "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=400"} 
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                        alt={song.title} 
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                         <div className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center scale-75 group-hover:scale-100 transition-transform duration-500">
                            <Play size={20} fill="currentColor" />
                         </div>
                      </div>
                      <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md border border-white/10 px-2 py-1 rounded-lg">
                         <span className="text-[9px] font-black italic text-primary">#{i + 1}</span>
                      </div>
                   </div>
                   <div className="p-5 space-y-1">
                      <h4 className="font-bold text-sm truncate group-hover:text-primary transition-colors">{song.title}</h4>
                      <div className="flex items-center justify-between">
                         <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest">{song.artist}</p>
                         <p className="text-[9px] text-white/20">{new Date(song.createdAt?.toDate?.()).toLocaleDateString()}</p>
                      </div>
                   </div>
                </GlassCard>
              </motion.div>
           )) : (
             <div className="col-span-full py-20 flex flex-col items-center justify-center space-y-6 text-center opacity-20 border-2 border-dashed border-white/5 rounded-[40px]">
                <Music size={48} strokeWidth={1} />
                <div className="space-y-2">
                   <p className="text-sm font-bold uppercase tracking-[0.2em]">Sube tu primer cover</p>
                   <p className="text-xs">Tu historial aparecerá aquí cronológicamente</p>
                </div>
                <Button variant="outline" icon={Plus}>Empezar en Studio</Button>
             </div>
           )}
        </div>
      </section>

      {/* Edit Profile Modal */}
      <AnimatePresence>
         {isEditing && (
           <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 sm:p-12">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsEditing(false)}
                className="absolute inset-0 bg-black/80 backdrop-blur-md"
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="w-full max-w-2xl relative z-10"
              >
                 <GlassCard className="p-10 space-y-8 !bg-surface-dim/80 !backdrop-blur-3xl border-primary/20 shadow-2xl">
                    <div className="flex items-center justify-between border-b border-white/5 pb-6">
                       <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary">
                             <Edit3 size={24} />
                          </div>
                          <div>
                             <h2 className="text-2xl font-display font-black uppercase tracking-tight">Editar Tu Perfil</h2>
                             <p className="text-[10px] text-white/40 font-bold uppercase tracking-widest">Personaliza tu identidad en la red</p>
                          </div>
                       </div>
                       <button onClick={() => setIsEditing(false)} className="p-2 text-white/20 hover:text-white transition-colors">
                          <X size={24} />
                       </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                       <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase text-white/40 tracking-widest ml-1">Nombre Público</label>
                          <input 
                            type="text" 
                            value={editData.displayName}
                            onChange={(e) => setEditData({...editData, displayName: e.target.value})}
                            className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-sm focus:outline-none focus:border-primary/50 transition-all font-bold"
                          />
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase text-white/40 tracking-widest ml-1">Nacionalidad</label>
                          <input 
                            type="text" 
                            value={editData.nationality}
                            onChange={(e) => setEditData({...editData, nationality: e.target.value})}
                            placeholder="Ej. España"
                            className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-sm focus:outline-none focus:border-primary/50 transition-all font-bold"
                          />
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase text-white/40 tracking-widest ml-1">Residencia</label>
                          <input 
                            type="text" 
                            value={editData.residence}
                            onChange={(e) => setEditData({...editData, residence: e.target.value})}
                            placeholder="Ej. Madrid"
                            className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-sm focus:outline-none focus:border-primary/50 transition-all font-bold"
                          />
                       </div>
                       <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase text-white/40 tracking-widest ml-1">Signo Zodiacal</label>
                          <select 
                            value={editData.zodiacSign}
                            onChange={(e) => setEditData({...editData, zodiacSign: e.target.value})}
                            className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-sm focus:outline-none focus:border-primary/50 transition-all font-bold appearance-none"
                          >
                             <option value="" className="bg-black">Seleccionar...</option>
                             {["Aries", "Tauro", "Géminis", "Cáncer", "Leo", "Virgo", "Libra", "Escorpio", "Sagitario", "Capricornio", "Acuario", "Piscis"].map(z => (
                               <option key={z} value={z} className="bg-black">{z}</option>
                             ))}
                          </select>
                       </div>
                       <div className="md:col-span-2 space-y-2">
                          <label className="text-[10px] font-black uppercase text-white/40 tracking-widest ml-1">Biografía / Reconocimiento</label>
                          <textarea 
                            value={editData.bio}
                            onChange={(e) => setEditData({...editData, bio: e.target.value})}
                            rows={4}
                            placeholder="Cuéntanos sobre tu visión..."
                            className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-sm focus:outline-none focus:border-primary/50 transition-all font-bold resize-none"
                          />
                       </div>
                    </div>

                    <div className="pt-4 flex gap-4">
                       <Button fullWidth icon={Save} onClick={handleUpdateProfile}>Guardar Cambios</Button>
                       <Button fullWidth variant="outline" onClick={() => setIsEditing(false)}>Cancelar</Button>
                    </div>
                 </GlassCard>
              </motion.div>
           </div>
         )}
      </AnimatePresence>
    </div>
  );
}

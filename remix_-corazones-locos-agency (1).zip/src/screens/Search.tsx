import { useState, useEffect } from "react";
import { Search as SearchIcon, Zap, Moon, Terminal, Play, Loader2 } from "lucide-react";
import { collection, query, where, getDocs, limit } from "firebase/firestore";
import { db } from "../lib/firebase";
import { GlassCard } from "../components/UI";

const categories = [
  { name: "Techno", desc: "El pulso de la noche", img: "https://images.unsplash.com/photo-1574672280600-4accfa5b6f98?q=80&w=600&auto=format&fit=crop", large: true },
  { name: "Synthwave", img: "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=400&auto=format&fit=crop" },
  { name: "Lo-fi", img: "https://images.unsplash.com/photo-1516280440614-37939bbacd81?q=80&w=400&auto=format&fit=crop" },
  { name: "Pop", img: "https://images.unsplash.com/photo-1493225255756-d9584f8606e9?q=80&w=400&auto=format&fit=crop" },
  { name: "House", img: "https://images.unsplash.com/photo-1571266028243-3716f02d2d2e?q=80&w=400&auto=format&fit=crop" }
];

const moods = [
  { name: "Energía Máxima", desc: "Para entrenar o salir", icon: Zap, color: "text-secondary" },
  { name: "Relax Nocturno", desc: "Baja las revoluciones", icon: Moon, color: "text-tertiary" },
  { name: "Enfoque Total", desc: "Música para estudiar", icon: Terminal, color: "text-primary" }
];

export default function Search() {
  const [searchTerm, setSearchTerm] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    const delayDebounceFn = setTimeout(async () => {
      if (searchTerm.trim().length > 2) {
        setIsSearching(true);
        try {
          const q = query(
            collection(db, "songs"),
            where("title", ">=", searchTerm),
            where("title", "<=", searchTerm + "\uf8ff"),
            limit(10)
          );
          const snap = await getDocs(q);
          setResults(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        } catch (e) {
          console.error(e);
        } finally {
          setIsSearching(false);
        }
      } else {
        setResults([]);
      }
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm]);

  const handlePlay = (song: any) => {
    const playEvent = new CustomEvent('play-track', { 
      detail: { 
        title: song.title, 
        author: song.artist,
        audioUrl: song.audioUrl,
        cover: `https://images.unsplash.com/photo-1614149162883-504ce4d13909?q=80&w=200&sig=${song.id}`
      } 
    });
    window.dispatchEvent(playEvent);
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <section className="space-y-6">
        <h2 className="text-4xl font-display font-black">Explorar</h2>
        <div className="relative group">
          <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none">
            {isSearching ? <Loader2 className="animate-spin text-primary" size={20} /> : <SearchIcon className="text-white/20 group-focus-within:text-primary transition-colors" size={20} />}
          </div>
          <input 
            type="text" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="¿Qué quieres escuchar hoy?"
            className="w-full bg-surface-bright/30 border border-white/5 rounded-full py-5 pl-16 pr-8 text-lg focus:outline-none focus:border-primary/50 focus:bg-surface-bright/50 transition-all font-display"
          />
        </div>

        {results.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 animate-in fade-in slide-in-from-top-2">
            {results.map((song) => (
              <div 
                key={song.id} 
                className="flex items-center gap-4 p-3 rounded-2xl bg-white/5 hover:bg-white/10 transition-all group cursor-pointer"
                onClick={() => handlePlay(song)}
              >
                <div className="relative w-12 h-12 rounded-xl overflow-hidden shrink-0">
                  <img src={`https://images.unsplash.com/photo-1614149162883-504ce4d13909?q=80&w=200&sig=${song.id}`} className="w-full h-full object-cover" alt="" />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play fill="white" size={20} />
                  </div>
                </div>
                <div>
                  <h6 className="font-bold text-white group-hover:text-primary transition-colors truncate">{song.title}</h6>
                  <p className="text-white/40 text-xs truncate">{song.artist}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="space-y-6">
        <h3 className="text-[10px] font-bold uppercase tracking-widest text-primary">Tendencias</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {categories.map((cat, i) => (
            <GlassCard 
              key={i} 
              className={`relative aspect-square group cursor-pointer ${cat.large ? 'col-span-2 row-span-2 md:aspect-auto' : ''}`}
            >
              <img 
                src={cat.img} 
                className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-110 transition-transform duration-700" 
                alt={cat.name}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-6 left-6">
                <span className={`font-display font-black text-white ${cat.large ? 'text-4xl' : 'text-xl'}`}>{cat.name}</span>
                {cat.desc && <p className="text-white/60 text-sm">{cat.desc}</p>}
              </div>
            </GlassCard>
          ))}
        </div>
      </section>

      <section className="space-y-6">
        <h3 className="text-[10px] font-bold uppercase tracking-widest text-primary">Categorías de Ánimo</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {moods.map((m, i) => {
            const Icon = m.icon;
            return (
              <GlassCard key={i} className="flex items-center gap-4 p-5 hover:bg-white/10 cursor-pointer">
                <div className={`w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center ${m.color}`}>
                  <Icon size={24} />
                </div>
                <div>
                  <p className="font-bold text-white mb-0.5">{m.name}</p>
                  <p className="text-white/40 text-xs">{m.desc}</p>
                </div>
              </GlassCard>
            );
          })}
        </div>
      </section>
    </div>
  );
}

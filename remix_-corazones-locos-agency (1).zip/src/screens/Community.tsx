import { useState, useEffect, useRef } from "react";
import { MoreHorizontal, MessageSquare, Repeat2, Heart, Share2, Shield, Lock, Loader2, Send, Play, Video, Crown, Music, ChevronRight } from "lucide-react";
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, limit, where, doc, updateDoc, increment } from "firebase/firestore";

import { GlassCard, Button } from "../components/UI";
import { auth, db, handleFirestoreError, OperationType } from "../lib/firebase";

interface PostRecord {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  isPublic: boolean;
  createdAt: any;
  songId?: string;
  songTitle?: string;
  type?: 'post' | 'videoclip' | 'chat';
  thumbnailUrl?: string;
  views?: number;
  likes?: number;
  dislikes?: number;
}

// Simple profanity filter
const OFFENSIVE_WORDS = ["mierda", "puto", "puta", "cabron", "gilipollas", "fuck", "shit", "asshole"];
const filterWords = (text: string) => {
  let filtered = text;
  OFFENSIVE_WORDS.forEach(word => {
    const regex = new RegExp(`\\b${word}\\b`, 'gi');
    filtered = filtered.replace(regex, "****");
  });
  return filtered;
};

export default function Community({ initialView, onBack, onNavigate }: { initialView?: string | null, onBack?: () => void, onNavigate?: (screen: any, subView?: string) => void }) {
  const [messages, setMessages] = useState<PostRecord[]>([]);
  const [videoclips, setVideoclips] = useState<PostRecord[]>([]);
  const [trendingVideoclips, setTrendingVideoclips] = useState<PostRecord[]>([]);
  const [topProducers, setTopProducers] = useState<any[]>([]);
  const [newUsers, setNewUsers] = useState<any[]>([]);
  const [showRanking, setShowRanking] = useState(initialView === 'ranking');
  const [isLoading, setIsLoading] = useState(true);
  const [newMessage, setNewMessage] = useState("");
  const [selectedSong, setSelectedSong] = useState<{ id: string, title: string } | null>(null);
  const [isPosting, setIsPosting] = useState(false);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [userSongs, setUserSongs] = useState<{ id: string, title: string }[]>([]);
  const [showSongSelector, setShowSongSelector] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (messages.length > 0) {
      scrollToBottom();
    }
  }, [messages]);

  useEffect(() => {
    if (initialView === 'ranking') {
      setShowRanking(true);
    } else {
      setShowRanking(false);
    }
  }, [initialView]);

  const handleBack = () => {
    setShowRanking(false);
    onBack?.();
  };

  useEffect(() => {
    if (auth.currentUser) {
      // Fetch user profile
      const unsubProfile = onSnapshot(doc(db, "users", auth.currentUser.uid), (snap) => {
        setUserProfile(snap.data());
      });

      // Fetch user songs for sharing
      const songsQuery = query(
        collection(db, "songs"),
        where("ownerId", "==", auth.currentUser.uid),
        orderBy("createdAt", "desc"),
        limit(10)
      );
      const unsubSongs = onSnapshot(songsQuery, (snap) => {
        setUserSongs(snap.docs.map(d => ({ id: d.id, title: d.data().title })));
      }, (error) => console.error("Error fetching songs for selector", error));

      return () => {
        unsubProfile();
        unsubSongs();
      };
    }
  }, []);

  useEffect(() => {
    const path = 'posts';
    
    // Chat messages listener
    const chatQuery = query(
      collection(db, path),
      where("isPublic", "==", true),
      where("type", "in", ["chat", "post"]), // Include legacy posts as chat messages
      orderBy("createdAt", "asc"),
      limit(50)
    );
    
    // Videoclips listener
    const videoQuery = query(
      collection(db, path),
      where("isPublic", "==", true),
      where("type", "==", "videoclip"),
      orderBy("createdAt", "desc"),
      limit(10)
    );

    // Trending Videoclips listener
    const trendingQuery = query(
      collection(db, path),
      where("isPublic", "==", true),
      where("type", "==", "videoclip"),
      orderBy("views", "desc"),
      limit(5)
    );

    const unsubChat = onSnapshot(chatQuery, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as PostRecord[];
      setMessages(docs);
      setIsLoading(false);
    }, (error) => handleFirestoreError(error, OperationType.LIST, path));

    const unsubVideos = onSnapshot(videoQuery, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as PostRecord[];
      setVideoclips(docs);
    }, (error) => handleFirestoreError(error, OperationType.LIST, path));

    const unsubTrending = onSnapshot(trendingQuery, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as PostRecord[];
      setTrendingVideoclips(docs);
    }, (error) => handleFirestoreError(error, OperationType.LIST, path));

    // Top Producers listener
    const producersQuery = query(
      collection(db, "users"),
      orderBy("followersCount", "desc"),
      limit(4)
    );
    const unsubProducers = onSnapshot(producersQuery, (snap) => {
      setTopProducers(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (error) => handleFirestoreError(error, OperationType.LIST, "users"));

    // New Users listener
    const newUsersQuery = query(
      collection(db, "users"),
      orderBy("createdAt", "desc"),
      limit(6)
    );
    const unsubNewUsers = onSnapshot(newUsersQuery, (snap) => {
      setNewUsers(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (error) => handleFirestoreError(error, OperationType.LIST, "users"));

    return () => {
      unsubChat();
      unsubVideos();
      unsubTrending();
      unsubProducers();
      unsubNewUsers();
    };
  }, []);

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !auth.currentUser) return;
    setIsPosting(true);
    const path = 'posts';
    
    try {
      await addDoc(collection(db, path), {
        userId: auth.currentUser.uid,
        userName: auth.currentUser.displayName || "Usuario Anónimo",
        userAvatar: auth.currentUser.photoURL || `https://i.pravatar.cc/150?u=${auth.currentUser.uid}`,
        content: filterWords(newMessage),
        isPublic: true,
        type: 'chat',
        songId: selectedSong?.id || null,
        songTitle: selectedSong?.title || null,
        createdAt: serverTimestamp()
      });
      setNewMessage("");
      setSelectedSong(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    } finally {
      setIsPosting(false);
    }
  };

  const mockRankings = Array.from({ length: 100 }, (_, i) => ({
    id: `rank-${i}`,
    userName: [
      "DJ Aero", "Lumina", "Vector Synth", "Neon Ghost", "Cyber Soul", 
      "Vapor Wave", "Midnight Echo", "Digital Nomad", "Prism", "Orbital"
    ][i % 10] + ` ${Math.floor(i / 10) || ''}`,
    views: 1200000 - (i * 11500),
    likes: Math.floor((1200000 - (i * 11500)) * 0.12),
    dislikes: Math.floor((1200000 - (i * 11500)) * 0.015),
    thumbnailUrl: [
      "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=400&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=400&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1459749411177-042180ce673f?q=80&w=400&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1550684848-fa1c684448e1?q=80&w=400&auto=format&fit=crop"
    ][i % 4]
  }));

  const handleSocialAction = async (postId: string, field: 'likes' | 'dislikes' | 'views') => {
    if (!auth.currentUser) return;
    try {
      await updateDoc(doc(db, 'posts', postId), {
        [field]: increment(1)
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `posts/${postId}`);
    }
  };

  const isPremium = userProfile?.plan === 'premium';

  if (showRanking) {
    return (
      <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
        <div className="flex items-center justify-between">
          <div>
             <button 
              onClick={handleBack}
              className="text-primary text-xs font-bold uppercase tracking-widest mb-2 hover:underline"
             >
               ← Volver a Comunidad
             </button>
             <h2 className="text-5xl font-display font-black">Top 100 Videoclips</h2>
          </div>
          <div className="bg-primary/10 px-6 py-3 rounded-2xl border border-primary/20">
             <p className="text-[10px] font-black text-primary uppercase tracking-[0.2em]">Actualizado</p>
             <p className="text-xl font-display font-bold">En tiempo real</p>
          </div>
        </div>

        <GlassCard className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="px-8 py-5 text-[10px] font-black text-white/40 uppercase tracking-widest">Puesto</th>
                  <th className="px-8 py-5 text-[10px] font-black text-white/40 uppercase tracking-widest">Artista</th>
                  <th className="px-8 py-5 text-[10px] font-black text-white/40 uppercase tracking-widest">Vistas</th>
                  <th className="px-8 py-5 text-[10px] font-black text-white/40 uppercase tracking-widest">Likes</th>
                  <th className="px-8 py-5 text-[10px] font-black text-white/40 uppercase tracking-widest">Dislikes</th>
                  <th className="px-8 py-5 text-[10px] font-black text-white/40 uppercase tracking-widest text-right">Acción</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {mockRankings.map((rank, i) => (
                  <tr key={rank.id} className="group hover:bg-white/[0.02] transition-colors">
                    <td className="px-8 py-5">
                      <span className={`text-2xl font-display font-black ${i < 3 ? 'text-primary' : 'text-white/20'}`}>
                        {String(i + 1).padStart(2, '0')}
                      </span>
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-4">
                        <div className="w-16 aspect-video rounded-lg overflow-hidden shrink-0 border border-white/10">
                          <img src={rank.thumbnailUrl} className="w-full h-full object-cover" alt="" />
                        </div>
                        <span className="font-bold text-white group-hover:text-primary transition-colors">{rank.userName}</span>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <span className="text-white/60 font-mono">{(rank.views / 1000).toFixed(1)}k</span>
                    </td>
                    <td className="px-8 py-5">
                      <span className="text-primary font-mono font-bold">{(rank.likes! / 1000).toFixed(1)}k</span>
                    </td>
                    <td className="px-8 py-5">
                      <span className="text-red-500/60 font-mono">{(rank.dislikes! / 1000).toFixed(1)}k</span>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <button className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white hover:bg-primary transition-all">
                        <Play size={16} fill="currentColor" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="space-y-16 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* 1. Premium Showcase */}
      <section className="space-y-8">
        <div className="flex justify-between items-end">
          <div>
            <span className="text-primary font-bold uppercase tracking-[0.2em] text-[10px] mb-2 block">Contenido VIP</span>
            <h2 className="text-4xl md:text-5xl font-display font-black tracking-tighter">Premium Showcase</h2>
          </div>
          <button 
            onClick={() => setShowRanking(true)}
            className="flex items-center gap-2 text-primary hover:text-white transition-colors font-bold text-xs uppercase tracking-widest"
          >
            <span>Ver todo</span>
            <ChevronRight size={16} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {(trendingVideoclips.length > 0 ? trendingVideoclips : [1, 2]).slice(0, 2).map((vid: any, i) => {
            const isReal = typeof vid === 'object';
            return (
              <GlassCard key={`showcase-${isReal ? vid.id : i}`} className="group relative overflow-hidden rounded-[32px] aspect-video md:aspect-[16/10] glow-purple">
                {isReal ? (
                  <>
                    <img src={vid.thumbnailUrl} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" alt="" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                    <div className="absolute bottom-0 left-0 p-8 w-full flex justify-between items-end">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <span className="bg-primary text-black text-[10px] px-2 py-0.5 rounded font-black uppercase tracking-tighter">4K Video</span>
                          <span className="text-white/60 text-xs font-bold uppercase tracking-widest">Top Rated</span>
                        </div>
                        <h3 className="text-2xl md:text-3xl font-display font-black text-white">{vid.songTitle || "Exclusive Premiere"}</h3>
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full border border-white/20 overflow-hidden">
                            <img src={vid.userAvatar} className="w-full h-full object-cover" alt="" />
                          </div>
                          <p className="font-bold text-white text-sm">{vid.userName}</p>
                        </div>
                      </div>
                      <button className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white shadow-2xl active:scale-95 transition-all glow-pink">
                        <Play size={32} fill="currentColor" stroke="none" />
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="w-full h-full bg-white/5 animate-pulse flex items-center justify-center">
                    <Video className="text-white/10" size={48} />
                  </div>
                )}
              </GlassCard>
            );
          })}
        </div>
      </section>

      {/* 2. Standard Covers (Paid Subs) */}
      <section className="space-y-8">
        <div>
          <span className="text-secondary font-bold uppercase tracking-[0.2em] text-[10px] mb-2 block">Nuevos Lanzamientos</span>
          <h2 className="text-3xl md:text-4xl font-display font-black tracking-tighter">Standard Covers</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-6">
          {(videoclips.length > 0 ? videoclips : Array.from({ length: 5 })).slice(0, 5).map((vid: any, i) => {
            const isReal = typeof vid === 'object';
            return (
              <div key={`cover-${isReal ? vid.id : i}`} className="space-y-4 group">
                <div className="relative aspect-square rounded-[24px] overflow-hidden glass-card">
                  {isReal ? (
                    <>
                      <img src={vid.thumbnailUrl} className="w-full h-full object-cover transition-transform group-hover:scale-110 duration-700" alt="" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                         <div className="w-12 h-12 bg-white text-black rounded-full flex items-center justify-center shadow-xl">
                            <Play size={24} fill="currentColor" />
                         </div>
                      </div>
                    </>
                  ) : (
                    <div className="w-full h-full bg-white/5 animate-pulse" />
                  )}
                </div>
                {isReal && (
                  <div>
                    <p className="font-bold text-white truncate text-sm">{vid.songTitle || "Untitled Cover"}</p>
                    <p className="text-white/40 text-xs truncate uppercase font-bold tracking-widest mt-1">{vid.userName}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. Community Pulse (Free Users & Activity) */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8">
          <h2 className="text-3xl font-display font-black tracking-tighter">Community Pulse</h2>
          
          {/* Chat/Post input moved here for Pulse */}
          <GlassCard className="p-1 overflow-hidden border-white/10 shadow-2xl">
            <div className="flex items-center gap-3 p-3">
              <img src={auth.currentUser?.photoURL || `https://i.pravatar.cc/150?u=${auth.currentUser?.uid}`} className="w-10 h-10 rounded-full border border-white/10" alt="" />
              <input 
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="¿Qué estás escuchando? Comparte con el club..."
                className="flex-1 bg-transparent border-none py-3 text-sm text-white focus:outline-none placeholder:text-white/20 font-medium"
              />
              <Button 
                onClick={handleSendMessage}
                disabled={isPosting || !newMessage.trim()}
                variant="primary"
                className="!py-2 !px-4"
              >
                {isPosting ? <Loader2 className="animate-spin" size={16} /> : "Post"}
              </Button>
            </div>
          </GlassCard>

          <div className="space-y-6">
            {messages.slice().reverse().map((msg) => (
              <GlassCard key={msg.id} className="p-6 space-y-4 hover:border-white/20 transition-all group">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img src={msg.userAvatar} className="w-10 h-10 rounded-full object-cover border border-white/10" alt="" />
                    <div>
                      <p className="font-bold text-white text-sm">
                        {msg.userName} 
                        <span className="text-primary text-[10px] ml-2 font-black uppercase tracking-widest opacity-60">● PÚBLICO</span>
                      </p>
                      <p className="text-[10px] text-white/40 font-bold uppercase tracking-widest">Posteó hace un momento</p>
                    </div>
                  </div>
                  <button className="text-white/20 hover:text-white transition-colors">
                    <MoreHorizontal size={20} />
                  </button>
                </div>
                <p className="text-white/80 text-sm leading-relaxed">{msg.content}</p>
                
                {msg.songId && (
                  <div className="bg-white/5 rounded-[20px] p-4 flex items-center gap-4 border border-white/5 group-hover:bg-white/10 transition-all cursor-pointer">
                    <div className="w-14 h-14 bg-gradient-to-br from-primary/20 to-tertiary/20 rounded-xl flex items-center justify-center text-primary border border-primary/20">
                      <Music size={20} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm text-white truncate">{msg.songTitle}</p>
                      <p className="text-[10px] text-white/40 uppercase font-black tracking-widest">Escuchar Track</p>
                    </div>
                    <div className="flex gap-2">
                        <button 
                          onClick={() => handleSocialAction(msg.id, 'likes')}
                          className="w-10 h-10 rounded-full flex items-center justify-center bg-white/5 hover:bg-white/10 transition-colors"
                        >
                           <Heart size={16} className={`transition-colors ${msg.likes ? 'text-primary' : 'text-white/40 hover:text-primary'}`} fill={msg.likes ? "currentColor" : "none"} />
                        </button>
                       <button className="w-10 h-10 rounded-full flex items-center justify-center bg-primary text-black glow-purple">
                          <Play size={18} fill="currentColor" stroke="none" />
                       </button>
                    </div>
                  </div>
                )}
              </GlassCard>
            ))}
          </div>
        </div>

        {/* Trending Sidebar */}
        <div className="space-y-8">
          <h3 className="text-2xl font-display font-black tracking-tighter">Trending</h3>
          <GlassCard className="p-8 space-y-8 border-white/10">
            {trendingVideoclips.map((vid, i) => (
              <div key={vid.id} className="flex items-center gap-5 group cursor-pointer">
                <span className="text-3xl font-display font-black text-white/10 group-hover:text-primary transition-colors italic">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <div 
                  className="flex-1 min-w-0"
                  onClick={() => handleSocialAction(vid.id, 'views')}
                >
                  <p className="font-bold text-white text-sm truncate group-hover:text-primary transition-colors">{vid.userName}</p>
                  <p className="text-[10px] text-white/40 font-black uppercase tracking-widest mt-1">{(vid.views || 0).toLocaleString()} vistas</p>
                </div>
                <div className="w-2 h-2 bg-secondary rounded-full shadow-[0_0_8px_#4ae176]" />
              </div>
            ))}
            
            {/* Ad/CTA for Free Users */}
            {!isPremium && (
              <div className="bg-gradient-to-br from-[#842bd2] to-[#f751a1] rounded-[24px] p-6 text-white space-y-4 shadow-2xl">
                <h4 className="font-display font-black text-xl leading-tight">¿Quieres ver clips exclusivos?</h4>
                <p className="text-xs font-bold opacity-80 leading-relaxed uppercase tracking-widest">Únete a C8L Premium para desbloquear Showcase y Standard Covers sin anuncios.</p>
                <Button 
                  onClick={() => onNavigate?.('pricing')} 
                  className="w-full bg-white !text-black font-black py-4 rounded-xl hover:bg-gray-100 transition-colors uppercase text-[10px] tracking-[0.2em]"
                >
                  Suscribirse ahora
                </Button>
              </div>
            )}
          </GlassCard>

          <h3 className="text-2xl font-display font-black tracking-tighter pt-4">Nuevos Miembros</h3>
          <div className="grid grid-cols-2 gap-4">
            {newUsers.map((user: any) => (
              <GlassCard key={user.id} className="p-5 text-center space-y-3 group hover:border-primary/30 transition-all">
                <div className="w-16 h-16 rounded-2xl mx-auto overflow-hidden border-2 border-white/10 group-hover:border-primary/50 transition-all p-1">
                  <img src={user.photoURL || `https://i.pravatar.cc/150?u=${user.id}`} alt="Avatar" className="w-full h-full object-cover rounded-xl" />
                </div>
                <h6 className="text-[10px] font-black text-white/60 uppercase tracking-widest truncate">{user.displayName || 'Artist'}</h6>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      {/* Floating Action Button (Mobile) */}
      <button className="fixed md:hidden bottom-28 right-6 w-16 h-16 bg-primary text-black rounded-full shadow-2xl flex items-center justify-center glow-purple z-40 active:scale-95 transition-transform">
        <Send size={24} />
      </button>
    </div>
  );
}

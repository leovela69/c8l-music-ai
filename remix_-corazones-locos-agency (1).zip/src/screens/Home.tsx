import { motion } from "motion/react";
import { Play, ChevronRight, MoreVertical } from "lucide-react";
import { GlassCard } from "../components/UI";

const playlists = [
  { title: "Cyberpunk Vibes", songs: "64 canciones", time: "4h 20m", img: "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=600&auto=format&fit=crop" },
  { title: "Indie Global", songs: "52 canciones", time: "3h 15m", img: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=600&auto=format&fit=crop" },
  { title: "Focus & Flow", songs: "128 canciones", time: "8h 45m", img: "https://images.unsplash.com/photo-1459749411177-042180ce673f?q=80&w=600&auto=format&fit=crop" },
  { title: "Clásicos Modernos", songs: "40 canciones", time: "2h 50m", img: "https://images.unsplash.com/photo-1493225255756-d9584f8606e9?q=80&w=600&auto=format&fit=crop" }
];

const covers = [
  "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=400&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=400&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1459749411177-042180ce673f?q=80&w=400&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1493225255756-d9584f8606e9?q=80&w=400&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1550684848-fa1c684448e1?q=80&w=400&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1614149162883-504ce4d13909?q=80&w=400&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1514525253361-b83f83df915e?q=80&w=400&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?q=80&w=400&auto=format&fit=crop",
];

const releases = [
  { title: "Neon Dreams", artist: "Nova Phase", type: "Sencillo", img: "https://images.unsplash.com/photo-1550684848-fa1c684448e1?q=80&w=200&auto=format&fit=crop" },
  { title: "Fragments of Light", artist: "Loomis & The Void", type: "Álbum", img: "https://images.unsplash.com/photo-1614149162883-504ce4d13909?q=80&w=200&auto=format&fit=crop" },
  { title: "Unspoken Words", artist: "Elena Soul", type: "EP", img: "https://images.unsplash.com/photo-1514525253361-b83f83df915e?q=80&w=200&auto=format&fit=crop" },
  { title: "Velocity", artist: "Rhythm Collective", type: "Sencillo", img: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?q=80&w=200&auto=format&fit=crop" }
];

const topVideoclips = [
  { id: 1, title: "Cybernetic Soul", artist: "Aero Synth", views: "1.2M", thumbnail: "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=800&auto=format&fit=crop" },
  { id: 2, title: "Neon Rainfall", artist: "Lumina", views: "850K", thumbnail: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=800&auto=format&fit=crop" },
  { id: 3, title: "Abstract Flow", artist: "Vector", views: "2.1M", thumbnail: "https://images.unsplash.com/photo-1459749411177-042180ce673f?q=80&w=800&auto=format&fit=crop" },
];

const radioSuggestions = [
  { title: "Acid Rain", artist: "Lorn", img: "https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=400" },
  { title: "Midnight City", artist: "M83", img: "https://images.unsplash.com/photo-1493225255756-d9584f8606e9?q=80&w=400" },
  { title: "Nightcall", artist: "Kavinsky", img: "https://images.unsplash.com/photo-1514525253361-b83f83df915e?q=80&w=400" },
  { title: "Genesis", artist: "Justice", img: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?q=80&w=400" },
  { title: "After Dark", artist: "Mr.Kitty", img: "https://images.unsplash.com/photo-1550684848-fa1c684448e1?q=80&w=400" },
  { title: "Resonance", artist: "Home", img: "https://images.unsplash.com/photo-1614149162883-504ce4d13909?q=80&w=400" },
];export default function Home({ onNavigate }: { onNavigate?: (screen: any, subView?: string) => void }) {
  return (
    <div className="space-y-16 animate-in fade-in slide-in-from-bottom-4 duration-1000">
      {/* Hero Section / Personalized Recommendations */}
      <section>
        <div className="flex items-end justify-between mb-8">
          <div>
            <span className="text-primary font-bold uppercase tracking-[0.2em] text-[10px] mb-2 block">Exclusivo para ti</span>
            <h2 className="text-4xl md:text-6xl font-display font-black tracking-tighter text-white">Recomendaciones</h2>
          </div>
          <button className="text-primary font-bold text-xs flex items-center gap-1 hover:opacity-80 transition-opacity uppercase tracking-widest">
            Ver todo <ChevronRight size={16} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Bento Card 1 */}
          <GlassCard className="relative rounded-[32px] overflow-hidden group col-span-1 md:col-span-2 aspect-[16/9] md:aspect-[21/9]">
            <img 
              src="https://images.unsplash.com/photo-1516280440614-37939bbacd81?q=80&w=1200" 
              className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-1000"
              alt="Night Vibes"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#000000] via-black/20 to-transparent p-10 flex flex-col justify-end">
              <div className="bg-[#ddb7ff] text-black text-[10px] font-black px-3 py-1 rounded-full w-fit mb-4 uppercase tracking-tighter glow-purple">Daily Mix</div>
              <h3 className="text-3xl md:text-4xl font-display font-black text-white mb-2">Energía Nocturna</h3>
              <p className="text-white/60 text-lg max-w-md leading-relaxed">Basado en tus reproducciones recientes de Techno y House melódico.</p>
            </div>
          </GlassCard>

          {/* Bento Card 2 - Radio */}
          <GlassCard className="relative rounded-[32px] overflow-hidden group aspect-square">
            <img 
              src="https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=600" 
              className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:scale-110 transition-transform duration-1000"
              alt="Radio"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#000000] via-black/40 to-transparent p-10 flex flex-col justify-end">
              <h3 className="text-3xl font-display font-black text-white text-2xl mb-1 italic">Radio C8L</h3>
              <p className="text-white/40 text-sm font-medium">Explora nuevos sonidos</p>
            </div>
          </GlassCard>
        </div>
      </section>

      {/* Featured Playlists Carousel */}
      <section>
        <div className="flex items-end justify-between mb-8">
          <h2 className="text-3xl md:text-5xl font-display font-black tracking-tighter text-white">Listas destacadas</h2>
          <div className="flex gap-2">
            <button className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/40 hover:text-white transition-colors">
              <ChevronRight className="rotate-180" size={20} />
            </button>
            <button className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/40 hover:text-white transition-colors">
              <ChevronRight size={20} />
            </button>
          </div>
        </div>

        <div className="flex gap-8 overflow-x-auto hide-scrollbar pb-4 snap-x">
          {playlists.map((pl, i) => (
            <motion.div 
              key={i} 
              whileHover={{ y: -8 }}
              className="min-w-[220px] group snap-start cursor-pointer"
            >
              <div className="aspect-square rounded-[24px] overflow-hidden mb-5 relative shadow-2xl shadow-primary/5">
                <img src={pl.img} className="w-full h-full object-cover transition-transform group-hover:scale-110 duration-700" alt={pl.title} />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity flex flex-col justify-center gap-4">
                  <div className="w-14 h-14 bg-primary text-black rounded-full flex items-center justify-center shadow-2xl scale-90 group-hover:scale-100 transition-all duration-300">
                    <Play size={28} fill="currentColor" />
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-bold text-white text-lg group-hover:text-primary transition-colors">{pl.title}</h4>
                <p className="text-white/40 text-sm font-medium">{pl.songs} • {pl.time}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* New Releases List */}
      <section className="pb-20">
        <div className="flex items-end justify-between mb-8">
          <h2 className="text-3xl md:text-5xl font-display font-black tracking-tighter text-white">Nuevos lanzamientos</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {releases.map((rel, i) => (
            <GlassCard key={i} className="flex items-center gap-5 p-5 hover:bg-white/5 cursor-pointer group">
              <div className="w-20 h-20 rounded-2xl overflow-hidden shrink-0">
                <img src={rel.img} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={rel.title} />
              </div>
              <div className="flex-1 min-w-0">
                <h5 className="font-bold text-white text-lg group-hover:text-primary transition-colors truncate">{rel.title}</h5>
                <p className="text-white/40 text-sm truncate font-medium">{rel.artist} • {rel.type}</p>
              </div>
              <button className="text-white/40 hover:text-white transition-colors p-2">
                <MoreVertical size={24} />
              </button>
            </GlassCard>
          ))}
        </div>
      </section>
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Scissors, Layers, Music, Mic2, Save, Download, Play, Pause, RotateCcw, 
  ChevronLeft, Crown, Zap, Sliders, Volume2, AudioWaveform as Wave, Plus, X,
  GripVertical, Settings, Sparkles, Wand2, Shield, Forward
} from "lucide-react";
import { GlassCard, Button } from "../components/UI";
import { auth, db } from "../lib/firebase";
import { doc, getDoc } from "firebase/firestore";

interface TrackStem {
  id: string;
  name: string;
  type: 'vocal' | 'instrument';
  instrument?: string;
  volume: number;
  muted: boolean;
}

export default function ProStudio({ track, onClose }: { track: any, onClose: () => void }) {
  const [isPremium, setIsPremium] = useState<boolean | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [activeTab, setActiveTab] = useState<'edit' | 'analyze' | 'effects'>('analyze');
  const [stems, setStems] = useState<TrackStem[]>([
    { id: 'v1', name: 'Vocal 1 (Lead)', type: 'vocal', volume: 85, muted: false },
    { id: 'v2', name: 'Vocal 2 (Doblaje)', type: 'vocal', volume: 65, muted: false },
    { id: 'c1', name: 'Coros & Armonías', type: 'vocal', volume: 55, muted: false },
    { id: 'i1', name: 'Guitarra Flamenca', type: 'instrument', instrument: 'Guitarra', volume: 75, muted: false },
    { id: 'i2', name: 'Congas & Percusión', type: 'instrument', instrument: 'Congas', volume: 60, muted: false },
    { id: 'i2b', name: 'Darbuka Rítmica', type: 'instrument', instrument: 'Darbuka', volume: 55, muted: false },
    { id: 'i3', name: 'Ukelele Tenor', type: 'instrument', instrument: 'Ukelele', volume: 45, muted: false },
    { id: 'i4', name: 'Arpa de Concierto', type: 'instrument', instrument: 'Arpa', volume: 40, muted: false },
    { id: 'i5', name: 'Acordeón Master', type: 'instrument', instrument: 'Acordeón', volume: 35, muted: false },
    { id: 'i6', name: 'Bajo Neural', type: 'instrument', instrument: 'Bajo', volume: 70, muted: false },
  ]);
  const [selectedStem, setSelectedStem] = useState<string | null>(null);
  const [trimRange, setTrimRange] = useState({ start: 20, end: 80 });

  useEffect(() => {
    async function checkPremium() {
      if (!auth.currentUser) return;
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      const data = userDoc.data();
      setIsPremium(data?.plan === 'premium');
    }
    checkPremium();
  }, []);

  if (isPremium === false) {
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center p-6 text-center"
      >
        <div className="max-w-md space-y-8">
           <div className="w-24 h-24 rounded-full bg-yellow-500/10 flex items-center justify-center mx-auto border border-yellow-500/20 glow-gold">
              <Crown className="text-yellow-500" size={48} />
           </div>
           <div className="space-y-4">
              <h2 className="text-4xl font-display font-black text-white uppercase tracking-tighter">Acceso Exclusivo Master Premium</h2>
              <p className="text-white/40 leading-relaxed uppercase text-[10px] font-black tracking-widest">
                El Estudio de IA Multicanal está reservado para creadores con suscripción Master Premium ($31.95). 
                Desbloquea la separación de capas, edición quirúrgica y sustitución de instrumentos.
              </p>
           </div>
           <div className="flex gap-4">
              <Button variant="outline" fullWidth onClick={onClose} className="border-white/10 text-white/40">Cerrar</Button>
              <Button variant="primary" fullWidth className="!bg-yellow-500 !text-black hover:!bg-yellow-400" onClick={() => window.location.hash = "#pricing"}>Mejorar Plan</Button>
           </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      className="fixed inset-0 z-[200] bg-[#050505] text-white flex flex-col font-sans"
    >
      {/* Premium Header */}
      <header className="h-20 bg-black/80 backdrop-blur-md border-b border-yellow-500/20 flex items-center justify-between px-8 relative z-10">
        <div className="flex items-center gap-6">
           <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full text-white/40 hover:text-white transition-colors">
              <ChevronLeft size={24} />
           </button>
           <div className="h-8 w-[1px] bg-white/10" />
           <div>
              <h1 className="text-xl font-display font-black uppercase tracking-tighter gold-text">Pro Studio Engine v5.5</h1>
              <p className="text-[9px] font-black uppercase tracking-widest text-white/20">Editando: {track?.title || "Nueva Creación"}</p>
           </div>
        </div>

        <div className="flex items-center gap-4">
           <div className="flex items-center gap-2 px-4 py-2 bg-yellow-500/10 border border-yellow-500/20 rounded-full">
              <Sparkles className="text-yellow-500" size={14} />
              <span className="text-[10px] font-black uppercase tracking-widest text-yellow-500">IA Activa (Neural Layering)</span>
           </div>
           <Button variant="outline" icon={Save} className="!border-white/10 !text-white/60 hover:!text-white">Guardar Sesión</Button>
           <Button variant="primary" icon={Download} className="!bg-yellow-500 !text-black hover:!bg-yellow-400">Exportar Master</Button>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
        {/* Left Sidebar - Stems Selector */}
        <aside className="w-80 bg-[#0a0a0a] border-r border-yellow-500/10 flex flex-col">
           <div className="p-6 space-y-6 flex-1 overflow-y-auto hide-scrollbar">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                   <Layers size={14} className="text-yellow-500" />
                   <h3 className="text-[10px] font-black uppercase tracking-widest text-white/40">Análisis por Capas</h3>
                </div>
                <button className="text-yellow-500/60 hover:text-yellow-500 transition-colors">
                   <Plus size={16} />
                </button>
              </div>

              <div className="space-y-2">
                 {stems.map((stem) => (
                   <motion.div 
                     key={stem.id}
                     onClick={() => setSelectedStem(stem.id)}
                     whileHover={{ x: 4 }}
                     className={`group flex flex-col gap-3 p-4 rounded-2xl border transition-all cursor-pointer
                       ${selectedStem === stem.id ? 'bg-yellow-500/10 border-yellow-500/40 shadow-[0_0_15px_rgba(234,179,8,0.1)]' : 'bg-white/5 border-white/5 hover:border-yellow-500/20 hover:bg-yellow-500/5'}
                     `}
                   >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                           {stem.type === 'vocal' ? <Mic2 size={16} className="text-blue-400 group-hover:scale-110 transition-transform" /> : <Music size={16} className="text-yellow-400 group-hover:scale-110 transition-transform" />}
                           <span className={`text-xs font-bold uppercase tracking-tight ${selectedStem === stem.id ? 'text-yellow-500' : 'text-white/80'}`}>{stem.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                           <button className="p-1 hover:bg-white/10 rounded transition-colors" title="Mute">
                              <Volume2 size={12} className={stem.muted ? "text-red-500" : "text-white/40"} />
                           </button>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                         <div className="flex-1 h-1 bg-white/5 rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${stem.volume}%` }}
                              className={`h-full ${stem.type === 'vocal' ? 'bg-blue-500/40' : 'bg-yellow-500/40'}`} 
                            />
                         </div>
                         <span className="text-[9px] font-mono text-white/20">{stem.volume}%</span>
                      </div>
                   </motion.div>
                 ))}
              </div>
           </div>
           
           <div className="p-6 border-t border-yellow-500/10 bg-yellow-500/[0.02]">
              <div className="flex items-center gap-3 text-yellow-500 mb-2">
                 <Wand2 size={18} className="animate-pulse" />
                 <span className="text-xs font-black uppercase tracking-tighter">Sustitución Neural</span>
              </div>
              <p className="text-[9px] text-white/40 uppercase font-black leading-relaxed mb-4 tracking-widest opacity-60 italic">Cambia instrumentos o voces manteniendo la melodía original.</p>
              <div className="grid grid-cols-2 gap-2">
                 <Button variant="outline" className="!bg-yellow-500/5 !border-yellow-500/20 !text-yellow-500 !text-[8px] !py-2 !px-1">Superponer</Button>
                 <Button variant="outline" className="!bg-white/5 !border-white/10 !text-white/60 !text-[8px] !py-2 !px-1">Sustituir</Button>
              </div>
           </div>
        </aside>

        {/* Timeline Area */}
        <section className="flex-1 bg-[#080808] flex flex-col relative overflow-hidden">
           {/* Grid Background */}
           <div className="absolute inset-0 opacity-10 pointer-events-none" 
                style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }} />

           {/* Toolbar */}
           <div className="h-16 bg-black/60 border-b border-yellow-500/10 flex items-center justify-between z-10 px-8">
              <div className="flex items-center gap-4">
                 <div className="flex items-center gap-2 p-1 bg-white/5 rounded-xl border border-white/5">
                    <button 
                      onClick={() => setActiveTab('analyze')}
                      className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${activeTab === 'analyze' ? 'bg-yellow-500 text-black shadow-lg' : 'text-white/40 hover:text-white'}`}
                    >Capa</button>
                    <button 
                      onClick={() => setActiveTab('edit')}
                      className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${activeTab === 'edit' ? 'bg-yellow-500 text-black shadow-lg' : 'text-white/40 hover:text-white'}`}
                    >Recortar</button>
                 </div>
                 <div className="h-6 w-[1px] bg-white/10" />
                 <div className="flex items-center gap-2">
                    <button className="p-2 text-white/40 hover:text-white hover:bg-white/5 rounded-lg transition-all" title="Cortar"><Scissors size={18} /></button>
                    <button className="p-2 text-white/40 hover:text-white hover:bg-white/5 rounded-lg transition-all" title="Mover"><GripVertical size={18} /></button>
                    <button className="p-2 text-white/40 hover:text-white hover:bg-white/5 rounded-lg transition-all" title="Undo"><RotateCcw size={18} /></button>
                 </div>
              </div>

              <div className="flex items-center gap-6">
                 <button className="text-white/40 hover:text-white transition-transform active:scale-95"><RotateCcw size={20} /></button>
                 <button 
                   onClick={() => setIsPlaying(!isPlaying)}
                   className="w-14 h-14 rounded-full bg-yellow-500 text-black flex items-center justify-center shadow-[0_0_30px_rgba(234,179,8,0.3)] hover:scale-105 active:scale-95 transition-all"
                 >
                    {isPlaying ? <Pause size={28} fill="currentColor" stroke="none" /> : <Play size={28} fill="currentColor" className="ml-1" stroke="none" />}
                 </button>
                 <button className="text-white/40 hover:text-white transition-transform active:scale-95"><Forward size={20} /></button>
              </div>

              <div className="flex items-center gap-8">
                 <div className="text-center">
                    <p className="text-[10px] font-black text-white/20 uppercase tracking-widest">Compás</p>
                    <p className="text-sm font-mono font-bold text-yellow-500/80">4/4</p>
                 </div>
                 <div className="text-center">
                    <p className="text-[10px] font-black text-white/20 uppercase tracking-widest">BPM</p>
                    <p className="text-sm font-mono font-bold text-yellow-500/80">128</p>
                 </div>
                 <div className="text-center">
                    <p className="text-[10px] font-black text-white/20 uppercase tracking-widest">Key</p>
                    <p className="text-sm font-mono font-bold text-yellow-500/80">Am</p>
                 </div>
              </div>
           </div>

           {/* Tracks Visualization */}
           <div className="flex-1 overflow-y-auto p-12 space-y-8 relative z-10 custom-scrollbar">
              {activeTab === 'edit' && (
                 <div className="mb-12 p-8 glass-card border-yellow-500/20 bg-yellow-500/[0.03] space-y-6">
                    <div className="flex items-center justify-between">
                       <h3 className="text-xs font-black uppercase text-yellow-500 tracking-widest flex items-center gap-2">
                          <Scissors size={14} /> Precisón Quirúrgica (Recorte)
                       </h3>
                       <p className="text-[10px] font-mono text-white/40">Range: {trimRange.start}% - {trimRange.end}%</p>
                    </div>
                    <div className="relative h-24 bg-black/40 rounded-2xl border border-white/5 overflow-hidden">
                       <div className="absolute inset-0 flex items-center px-4 opacity-20">
                          {Array.from({ length: 60 }).map((_, i) => (
                             <div key={i} className="flex-1 h-full flex flex-col justify-center gap-[2px]">
                                <div className="w-[2px] bg-white h-4 mx-auto opacity-20" />
                                <div className="w-[3px] bg-white h-8 mx-auto" />
                                <div className="w-[2px] bg-white h-4 mx-auto opacity-20" />
                             </div>
                          ))}
                       </div>
                       {/* Trim Selector Overlay */}
                       <div className="absolute inset-0 flex">
                          <div className="h-full bg-black/60 backdrop-blur-[1px]" style={{ width: `${trimRange.start}%` }} />
                          <div className="h-full flex-1 border-x-2 border-yellow-500 relative bg-yellow-500/5 group">
                             <div className="absolute top-0 bottom-0 left-0 w-4 cursor-ew-resize flex items-center justify-center">
                                <div className="w-1 h-8 bg-yellow-500 rounded-full" />
                             </div>
                             <div className="absolute top-0 bottom-0 right-0 w-4 cursor-ew-resize flex items-center justify-center">
                                <div className="w-1 h-8 bg-yellow-500 rounded-full" />
                             </div>
                             <div className="absolute inset-x-0 bottom-2 flex justify-center">
                                <span className="text-[8px] font-black text-yellow-500 uppercase tracking-widest bg-black/80 px-2 py-1 rounded">Área de Trabajo</span>
                             </div>
                          </div>
                          <div className="h-full bg-black/60 backdrop-blur-[1px]" style={{ width: `${100 - trimRange.end}%` }} />
                       </div>
                    </div>
                    <div className="flex justify-end gap-3">
                       <button className="px-4 py-2 bg-white/5 text-white/40 text-[9px] font-black uppercase rounded-lg hover:text-white transition-colors">Reset</button>
                       <button className="px-6 py-2 bg-yellow-500 text-black text-[9px] font-black uppercase rounded-lg hover:shadow-[0_0_15px_rgba(234,179,8,0.4)] transition-all">Recortar & Aplicar</button>
                    </div>
                 </div>
              )}

              {stems.map((stem, idx) => (
                <div 
                  key={stem.id} 
                  className={`relative group transition-all duration-500 ${selectedStem === stem.id ? 'scale-[1.02] z-20' : 'opacity-40 grayscale-[0.5] hover:opacity-100 hover:grayscale-0'}`}
                  onClick={() => setSelectedStem(stem.id)}
                >
                   <div className={`absolute -left-6 top-1/2 -translate-y-1/2 w-1.5 h-12 bg-yellow-500 rounded-full transition-all duration-500 ${selectedStem === stem.id ? 'opacity-100 scale-y-100 shadow-[0_0_15px_#eab308]' : 'opacity-0 scale-y-0'}`} />
                   <div className="flex gap-8 items-center">
                      <div className={`w-16 h-16 rounded-[24px] flex items-center justify-center border transition-all duration-500
                        ${selectedStem === stem.id ? 'bg-yellow-500 shadow-[0_0_20px_rgba(234,179,8,0.2)] border-yellow-400 rotate-3' : 'bg-white/5 border-white/10 group-hover:border-yellow-500/30'}
                      `}>
                         {stem.type === 'vocal' 
                           ? <Mic2 size={24} className={selectedStem === stem.id ? "text-black" : "text-blue-400/50"} /> 
                           : <Music size={24} className={selectedStem === stem.id ? "text-black" : "text-yellow-400/50"} />
                         }
                      </div>
                      <div className={`flex-1 h-28 rounded-[32px] border transition-all duration-500 relative overflow-hidden flex items-center
                        ${selectedStem === stem.id ? 'bg-yellow-500/[0.08] border-yellow-500/50' : 'bg-white/[0.03] border-white/5 group-hover:bg-white/[0.08]'}
                      `}>
                         {/* Full Dynamic Waveform */}
                         <div className="absolute inset-0 flex items-center gap-[2px] px-8">
                            {Array.from({ length: 140 }).map((_, i) => (
                              <motion.div 
                                key={i} 
                                animate={isPlaying ? {
                                  height: [`${Math.random() * 60 + 10}%`, `${Math.random() * 60 + 10}%`, `${Math.random() * 60 + 10}%`]
                                } : {}}
                                transition={{ repeat: Infinity, duration: 0.5 + Math.random() }}
                                className={`w-[2px] rounded-full transition-colors duration-500 ${selectedStem === stem.id ? (stem.type === 'vocal' ? 'bg-blue-400' : 'bg-yellow-500 shadow-[0_0_8px_rgba(234,179,8,0.5)]') : 'bg-white/10'}`}
                                style={{ height: `${Math.random() * 40 + 10}%` }}
                              />
                            ))}
                         </div>
                         
                         {/* HUD Label */}
                         <div className="absolute top-4 left-8 flex items-center gap-3">
                            <span className={`text-[9px] font-black uppercase tracking-[0.2em] px-2 py-0.5 rounded border transition-colors
                              ${selectedStem === stem.id ? 'bg-yellow-500 text-black border-yellow-400' : 'bg-black/40 text-white/40 border-white/10'}
                            `}>{stem.name}</span>
                         </div>

                         <div className="absolute inset-y-0 right-0 w-48 flex items-center justify-end px-8 opacity-0 group-hover:opacity-100 transition-opacity bg-gradient-to-l from-black/60 to-transparent">
                            <button className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-yellow-500 hover:text-black transition-all shadow-xl backdrop-blur-md border border-white/10">
                               <Settings size={20} />
                            </button>
                         </div>
                      </div>
                   </div>
                </div>
              ))}
           </div>

           {/* Master Slider & Info */}
           <div className="h-32 bg-black/60 border-t border-white/10 backdrop-blur-xl flex items-center px-8 gap-12">
              <div className="flex items-center gap-6">
                 <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-yellow-500/20 to-black border border-yellow-500/30 flex items-center justify-center">
                    <Wave className="text-yellow-500" size={32} />
                 </div>
                 <div>
                    <h4 className="text-sm font-black uppercase tracking-widest text-yellow-500">Neural Master Out</h4>
                    <div className="flex items-center gap-3">
                       <div className="w-48 h-1 bg-white/10 rounded-full overflow-hidden">
                          <div className="h-full bg-gradient-to-r from-yellow-500 to-white w-3/4" />
                       </div>
                       <span className="text-xs font-mono text-white/40">-6.2 dB</span>
                    </div>
                 </div>
              </div>

              <div className="flex-1 max-w-xl h-12 bg-white/5 rounded-2xl flex items-center px-6 border border-white/5">
                 <Sliders className="text-white/20 mr-4" size={18} />
                 <div className="flex-1 h-[2px] bg-white/10 rounded-full relative">
                    <div className="absolute top-1/2 -translate-y-1/2 left-[40%] w-4 h-4 bg-yellow-500 rounded-full border-4 border-black shadow-lg cursor-pointer" />
                 </div>
                 <div className="ml-6 flex items-center gap-2">
                    <span className="text-[10px] font-black text-yellow-500">STEREO WIDE</span>
                    <span className="text-[10px] font-mono font-bold">120%</span>
                 </div>
              </div>
           </div>
        </section>

        {/* Right Sidebar - Effects/Instruments */}
        <aside className="w-72 bg-[#0a0a0a] border-l border-yellow-500/10 flex flex-col p-8 gap-10">
           <div className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-white/40 mb-4 flex items-center gap-2">
                 <Wand2 size={12} className="text-yellow-500" /> Neural Studio v5
              </h4>
              <div className="flex gap-1 p-1 bg-white/5 rounded-xl border border-white/5">
                 <button 
                   onClick={() => setActiveTab('analyze')}
                   className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest rounded-lg transition-all ${activeTab === 'analyze' ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/20' : 'text-white/40 hover:text-white'}`}
                 >Voces</button>
                 <button 
                   onClick={() => setActiveTab('effects')}
                   className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest rounded-lg transition-all ${activeTab === 'effects' ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/20' : 'text-white/40 hover:text-white'}`}
                 >Fx IA</button>
              </div>
           </div>

           <div className="flex-1 overflow-y-auto space-y-8 hide-scrollbar">
              {activeTab === 'analyze' ? (
                <>
                   <div className="space-y-4">
                      <p className="text-[10px] font-black uppercase tracking-widest text-white/20">Remodelado Vocal</p>
                      <div className="space-y-3">
                         {['Original Clean', 'Voz de Barítono', 'Soprano Crystal', 'Robot 808', 'Voz de Jazz'].map(v => (
                            <button key={v} className="w-full flex items-center justify-between p-4 bg-white/5 border border-white/5 rounded-2xl group hover:border-yellow-500/40 transition-all">
                               <span className="text-[10px] font-bold text-white/60 group-hover:text-white">{v}</span>
                               <div className="w-2 h-2 rounded-full border border-white/20 group-hover:bg-yellow-500 group-hover:border-yellow-500" />
                            </button>
                         ))}
                      </div>
                   </div>
                   
                   <div className="space-y-4">
                      <p className="text-[10px] font-black uppercase tracking-widest text-white/20">Substituir Instrumento</p>
                      <div className="grid grid-cols-2 gap-3">
                         {['Guitarra Nylon', 'Sitar AI', 'Piano Kawai', 'Bajo Moog', 'Violín Solo', 'Sax Alto', 'Ukelele', 'Darbuka', 'Acordeón'].map(inst => (
                           <button 
                             key={inst} 
                             className="p-3 bg-black border border-white/5 rounded-2xl text-[8px] font-black uppercase hover:border-yellow-500/50 hover:bg-yellow-500/10 hover:text-yellow-500 transition-all text-center leading-tight shadow-md"
                           >
                             {inst}
                           </button>
                         ))}
                      </div>
                   </div>
                </>
              ) : (
                <div className="space-y-4">
                   <p className="text-[10px] font-black uppercase tracking-widest text-white/20">Audio Intelligence FX</p>
                   <div className="space-y-3">
                      {[
                        { name: 'Neural Reverb', vol: 40 },
                        { name: 'Quantum Delay', vol: 65 },
                        { name: 'Cosmos Widener', vol: 20 },
                        { name: 'AI Compressor', vol: 80 },
                        { name: 'Spectral EQ', vol: 50 },
                        { name: 'Auto-Pitch Pro', vol: 100 }
                      ].map(fx => (
                        <div key={fx.name} className="p-4 bg-white/5 border border-white/10 rounded-2xl space-y-3 group hover:border-yellow-500/20 transition-all">
                           <div className="flex items-center justify-between">
                              <span className="text-[9px] font-black uppercase text-white/60 group-hover:text-yellow-500 transition-colors">{fx.name}</span>
                              <div className={`w-10 h-5 rounded-full relative transition-colors ${fx.vol > 0 ? 'bg-yellow-500/20' : 'bg-white/10'}`}>
                                 <div className={`absolute top-1 bottom-1 w-3 bg-yellow-500 rounded-full transition-all ${fx.vol > 0 ? 'right-1' : 'left-1'}`} />
                              </div>
                           </div>
                           <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                              <div className="h-full bg-yellow-500/40" style={{ width: `${fx.vol}%` }} />
                           </div>
                        </div>
                      ))}
                   </div>
                </div>
              )}
           </div>

           <GlassCard className="!bg-yellow-500/10 border-yellow-500/20 p-6 relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                 <Shield size={64} className="text-yellow-500" />
              </div>
              <div className="flex items-center gap-2 text-yellow-500 mb-3 relative z-10">
                 <Shield size={16} />
                 <span className="text-[10px] font-black uppercase tracking-widest">Quantum Engine</span>
              </div>
              <p className="text-[9px] text-white/60 uppercase font-black leading-relaxed relative z-10 opacity-80 decoration-yellow-500/20">Archivos protegidos por Blockchain Studio™.</p>
           </GlassCard>
        </aside>
      </main>

      <style>{`
        .gold-text {
          background: linear-gradient(to bottom, #fde047 0%, #eab308 50%, #854d0e 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .glow-gold {
          box-shadow: 0 0 40px rgba(234, 179, 8, 0.2);
        }
        .glow-white {
          box-shadow: 0 0 30px rgba(255, 255, 255, 0.1);
        }
        .hide-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .hide-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(234, 179, 8, 0.1);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(234, 179, 8, 0.3);
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 8s linear infinite;
        }
      `}</style>
    </motion.div>
  );
}

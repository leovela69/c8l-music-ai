import { motion } from "motion/react";
import { LucideIcon, Loader2 } from "lucide-react";
import { ReactNode } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  key?: any;
}

export const GlassCard = ({ children, className = "", onClick }: GlassCardProps) => (
  <motion.div 
    whileHover={onClick ? { scale: 1.02 } : undefined}
    whileTap={onClick ? { scale: 0.98 } : undefined}
    onClick={onClick}
    className={`glass-card ${className}`}
  >
    {children}
  </motion.div>
);

interface ButtonProps {
  children?: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'premium';
  className?: string;
  icon?: LucideIcon;
  fullWidth?: boolean;
  disabled?: boolean;
}

export const Button = ({ children, onClick, variant = 'primary', className = "", icon: Icon, fullWidth, disabled }: ButtonProps) => {
  const variants = {
    primary: "bg-primary text-[#000000] hover:scale-105 active:scale-95 glow-purple",
    secondary: "bg-surface-bright text-white hover:bg-surface-bright/80",
    outline: "border border-white/20 text-white hover:bg-white/10",
    ghost: "text-white/60 hover:text-white hover:bg-white/5",
    premium: "bg-gradient-to-r from-primary-container to-tertiary-container text-white glow-pink hover:scale-105 active:scale-95"
  };

  return (
    <motion.button
      whileHover={disabled ? undefined : { scale: 1.02 }}
      whileTap={disabled ? undefined : { scale: 0.98 }}
      disabled={disabled}
      onClick={onClick}
      className={`
        px-6 py-3 rounded-full font-display font-bold uppercase tracking-widest text-xs 
        transition-all flex items-center justify-center gap-2
        ${variants[variant]} 
        ${fullWidth ? 'w-full' : ''} 
        ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
        ${className}
      `}
    >
      {Icon && <Icon size={16} className={disabled && Icon === Loader2 ? 'animate-spin' : ''} />}
      {children}
    </motion.button>
  );
};

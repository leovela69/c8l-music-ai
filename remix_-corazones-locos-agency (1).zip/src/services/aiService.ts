export const aiService = {
  async refineLyrics(currentLyrics: string): Promise<string> {
    try {
      const response = await fetch("/api/ai/refine-lyrics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentLyrics }),
      });
      const data = await response.json();
      return data.text || currentLyrics;
    } catch (error) {
      console.error("Error refining lyrics:", error);
      return currentLyrics;
    }
  },

  async refinePrompt(promptText: string, isNegative: boolean = false): Promise<string> {
    try {
      const response = await fetch("/api/ai/refine-prompt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ promptText, isNegative }),
      });
      const data = await response.json();
      return data.text || promptText;
    } catch (error) {
      console.error("Error refining prompt:", error);
      return promptText;
    }
  },

  async extendLyrics(currentLyrics: string): Promise<string> {
    // We could add an endpoint for this too, or reuse refine-lyrics with a flag
    // For simplicity, let's keep the logic consistent
    try {
      const response = await fetch("/api/ai/refine-lyrics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          currentLyrics: `Continúa esta letra con una estrofa y estribillo nuevos: ${currentLyrics}`
        }),
      });
      const data = await response.json();
      return currentLyrics + "\n\n" + (data.text || "");
    } catch (error) {
      return currentLyrics;
    }
  },

  async createRemixPrompt(originalStyle: string): Promise<string> {
    try {
      const response = await fetch("/api/ai/refine-prompt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          promptText: `Create a remix variation of this style: ${originalStyle}`,
          isNegative: false
        }),
      });
      const data = await response.json();
      return data.text || originalStyle;
    } catch (error) {
      return originalStyle;
    }
  }
};

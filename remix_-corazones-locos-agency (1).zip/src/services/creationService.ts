export interface SongPlan {
  title: string;
  genre: string;
  tempo: string;
  mood: string;
  lyrics: string[];
  structure: string[];
  visualPrompt: string;
  aiVersion: string;
  layers?: Array<{ name: string; type: 'vocal' | 'instrumental'; volume: number }>;
}

export interface SongRequest {
  lyricsPrompt?: string;
  positiveStyle: string;
  negativeStyle: string;
  lyricsInfluence: number;
  promptInfluence: number;
  voiceInfluence: number;
  selectedVoiceId?: string;
  aiVersion: string;
}

export const creationService = {
  async planSong(req: SongRequest): Promise<SongPlan> {
    try {
      const response = await fetch("/api/ai/plan-song", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(req),
      });
      
      if (!response.ok) throw new Error("Failed to generate song plan");
      
      return await response.json();
    } catch (e) {
      console.error("Failed to fetch song plan", e);
      throw new Error("Error generating song plan");
    }
  },

  async generateVisualizerPrompt(songTitle: string, genre: string): Promise<string> {
    try {
      const response = await fetch("/api/ai/refine-prompt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          promptText: `Premium music visualizer for song "${songTitle}" in "${genre}" genre`,
          isNegative: false
        }),
      });
      const data = await response.json();
      return data.text || `Visualizer for ${songTitle}`;
    } catch (error) {
      return `Visualizer for ${songTitle}`;
    }
  }
};

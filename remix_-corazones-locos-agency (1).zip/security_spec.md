# Security Specification - Corazones Locos Agency

## Data Invariants
1. **User Integrity**: A user document must be owned by the authenticated user.
2. **Subscription Lock**: A user cannot upgrade their `plan` or `credits` arbitrarily (in a real app, this would be server-side, here we'll use action-based updates to limit exposure).
3. **Song Ownership**: Songs are immutable in their `ownerId`. 
4. **Post Visibility**: Private posts (if any) are only readable by the owner. Public posts are readable by any signed-in user.
5. **Timestamp Integrity**: `createdAt` and `updatedAt` must be set via `request.time`.

## The Dirty Dozen Payloads (Red Team Test Cases)

1. **Identity Spoofing (User)**: Create a user document with a different UID in the data than `request.auth.uid`.
2. **Email Hijack**: Update another user's email field.
3. **Credit Injection**: Update my own `credits` by 1,000,000 without a valid action.
4. **Plan Escalation**: Change my `plan` from 'free' to 'premium' without a simulated purchase action.
5. **Orphan Song**: Create a song where `ownerId` doesn't match my UID.
6. **Post Ghosting**: Create a post with a `userId` that isn't mine.
7. **View Manipulation**: Artificially increment `views` on a videoclip by 1,000 in one update.
8. **Shadow Field**: Add an `isAdmin: true` field to a user document.
9. **ID Poisoning**: Create a document with a 2KB junk string as the ID.
10. **PII Leak**: Read another user's private data (bio, residence) without permission.
11. **Timestamp Faking**: Set `createdAt` to a date in the past.
12. **Metadata Tampering**: Change the `ownerId` of an existing song.

## Test Runner Plan
We will use `firestore.rules.test.ts` to verify these failure cases.

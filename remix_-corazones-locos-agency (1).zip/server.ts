import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // AI API Routes
  app.post("/api/ai/refine-lyrics", async (req, res) => {
    const { currentLyrics } = req.body;
    const prompt = currentLyrics?.trim().length > 0 
      ? `Act como un compositor experto de música urbana y pop. Mejora o completa la siguiente letra de canción, manteniendo el sentimiento pero haciéndola más profesional y pegadiza: "${currentLyrics}"`
      : "Escribe una estrofa y un estribillo para una canción de éxito actual. Estilo libre pero pegadizo.";

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          systemInstruction: "Eres un compositor de música profesional (Ghostwriter). Solo devuelve la letra de la canción, sin explicaciones ni introducciones.",
        },
      });
      res.json({ text: response.text });
    } catch (error) {
      console.error("Error refining lyrics:", error);
      res.status(500).json({ error: "Failed to refine lyrics" });
    }
  });

  app.post("/api/ai/refine-prompt", async (req, res) => {
    const { promptText, isNegative } = req.body;
    const systemInstruction = isNegative 
      ? "Eres un experto en prompt engineering para generación de música por IA. Tu tarea es convertir una lista de palabras negativas simples en un prompt negativo técnico y efectivo para mejorar la calidad del audio."
      : "Eres un experto en prompt engineering para generación de música por IA. Convierte ideas simples de estilo en prompts técnicos detallados.";

    const basePrompt = isNegative 
      ? `Mejora este prompt negativo: "${promptText}"`
      : `Convierte estos conceptos en un prompt detallado: "${promptText}"`;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: basePrompt,
        config: {
          systemInstruction: systemInstruction + " Solo devuelve el prompt resultante separado por comas, sin explicaciones.",
        },
      });
      res.json({ text: response.text });
    } catch (error) {
      res.status(500).json({ error: "Failed to refine prompt" });
    }
  });

  app.post("/api/ai/plan-song", async (req, res) => {
    const { lyricsPrompt, positiveStyle, negativeStyle, lyricsInfluence, promptInfluence, voiceInfluence, aiVersion } = req.body;
    
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Create a professional music composition plan.
            - User Lyrics/Theme: "${lyricsPrompt || 'Original composition'}"
            - Style to follow (Positive): "${positiveStyle}"
            - Styles to avoid (Negative): "${negativeStyle}"
            - Lyrics Influence: ${lyricsInfluence}%
            - Style Influence: ${promptInfluence}%
            - Voice Texture Influence: ${voiceInfluence}%
            - AI Engine Version: ${aiVersion}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              genre: { type: Type.STRING },
              tempo: { type: Type.STRING },
              mood: { type: Type.STRING },
              lyrics: { type: Type.ARRAY, items: { type: Type.STRING } },
              structure: { type: Type.ARRAY, items: { type: Type.STRING } },
              visualPrompt: { type: Type.STRING },
              aiVersion: { type: Type.STRING },
              layers: { 
                type: Type.ARRAY, 
                items: { 
                  type: Type.OBJECT, 
                  properties: {
                    name: { type: Type.STRING },
                    type: { type: Type.STRING },
                    volume: { type: Type.NUMBER }
                  }
                }
              }
            },
            required: ["title", "genre", "tempo", "mood", "lyrics", "structure", "visualPrompt", "aiVersion", "layers"]
          }
        }
      });
      res.json(JSON.parse(response.text || "{}"));
    } catch (error) {
      console.error("Plan song error:", error);
      res.status(500).json({ error: "Failed to plan song" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
